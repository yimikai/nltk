# -*- coding: utf-8 -*-
import sys
import os
import time
import shutil
import numpy as np
from PIL import Image
from glob import glob
import cv2
import os
import json
import shutil
import cv2
import traceback
from PIL import Image
sys.path.append("./pyscripts")
import numpy as np
import math
import copy
from loadorigintxt_1s import *
from loadoriginsound import * 
import pyscripts.getshots_img as getshots_img
import pyscripts.comm_log as comm_log
import shuping_ocr.OcrCheckTools as OcrCheckTools
import Tool.Tool as Tool
import pyscripts.tool as tool
import pyscripts.makeAudioRange as makeAudioRange
import random
import pyscripts.overlap as overlap
import pyscripts.print_c as print_c
import pyscripts.audio_pause as audio_pause
import pyscripts.detectBlack as detectBlack
import pyscripts.assert_info as assert_info
import pyscripts.txtSplit as mergeSoundTxt



# 保存图片，用于观察结果
def saveimg(im,savepath):#img is cv2 format
	comm_log.info(savepath)
	cv2.imwrite(savepath,im)
	return 0,0

'''
shots content format:

{"sec_shots": [[0.0, 0.44], [0.56, 2.88], [3.0, 4.2], [4.32, 7.2], [7.32, 10.68], [10.8, 13.8], [13.92, 16.32], [16.44, 18.32], [18.44, 44.36], [44.48, 49.68], [49.8, 52.12], [52.24, 53.84], [53.96, 56.4], [56.52, 62.16], [62.28, 64.04], [64.16, 99.16], [99.28, 100.36], [100.48, 125.12], [125.24, 128.96], [129.08, 131.88], [132.0, 134.96], [135.08, 139.36], [139.48, 142.16], [142.28, 146.36], [146.48, 149.68], [149.8, 154.16], [154.28, 158.0], [158.12, 165.28]], "shots": [[0, 11], [14, 72], [75, 105], [108, 180], [183, 267], [270, 345], [348, 408], [411, 458], [461, 1109], [1112, 1242], [1245, 1303], [1306, 1346], [1349, 1410], [1413, 1554], [1557, 1601], [1604, 2479], [2482, 2509], [2512, 3128], [3131, 3224], [3227, 3297], [3300, 3374], [3377, 3484], [3487, 3554], [3557, 3659], [3662, 3742], [3745, 3854], [3857, 3950], [3953, 4132]]}
'''

#保存结果，用于观察
def outresult2(video_path, vid, s_range):
	try:
		out_dict = {}
		out_dict[vid]={"frame_story":s_range}
		json.dump(out_dict, open("./result/"+vid+"_story.json",'w'))


		comm_log.info(video_path)
		cap = cv2.VideoCapture(video_path)
		
		total_frames_num = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
		comm_log.info("total num=%d"%total_frames_num)
		fps=int(cap.get(cv2.CAP_PROP_FPS))
		
		s_range_list = np.concatenate(s_range).tolist()
		
		num = -1
		s_num = 1 
		sucess = True #,im0 = cap.read() # get next frame
		while sucess:
			num+=1
			sucess,im0 = cap.read() # get next frame
			if not sucess:
				break
			im = cv2.resize(im0,(360,270))
			# find in story boundary 
			if num in s_range_list:
				s_num+=1
				if  s_num%2==0:
					# save shots imgs before shots interval 
					comm_log.info("-----------")
					savepath=frames_folder+"/"+str(num)+"_story_"+str(float(s_num/2))+".jpg"
					res, after_segments = saveimg(im,savepath)
				else:
					savepath=frames_folder+"/"+str(num)+"_story_"+str(float(s_num/2))+".jpg"
					res, after_segments = saveimg(im,savepath)
		cap.release()
		comm_log.info("-youxiao frames = "+str(num))
	except Exception as e:
		comm_log.info(traceback.format_exc())
		comm_log.info(e)
	return 


def saveresult(s_range, video_path, vid):
	global frames_folder
	frames_folder = "./data_storys/shots_"+vid
	if os.path.exists(frames_folder)==False:
	    os.makedirs(frames_folder)
	else:
	    shutil.rmtree(frames_folder)
	    os.makedirs(frames_folder)
	if os.path.exists(video_path):
	    outresult2(video_path, vid, s_range)

def detect_videoblack(vid):
	video_imgpath = "./image_dir/"+str(vid)
    	result,black_ratio, bbox, area_ratio = detectBlack.detectBlack(video_imgpath)
	if black_ratio > 0.9 and 0.6<area_ratio<0.9:
		return True,  bbox	
	return False, []


def processAudio(video_path,shot_content, vid, fps, threshold, yin_height):
	audiorange = []
	audiorange = makeAudioRange.makeAudioRange(video_path, shot_content,vid, fps, threshold, yin_height)
	comm_log.info("sound is empty, then use audio stops: audiorange="+str(audiorange))
	return audiorange

def check_storyrange_byocr(story_range_list, ocr_range, tvrangelist, totalframes):
	story_range_new = []
	for item in story_range_list:
		flag1, _ = overlap.overalllap(item, ocr_range)
		flag2, _ = overlap.overalllap(item, tvrangelist)
		if flag1==False and flag2==False:
			#story_range_list.remove(item)
			continue
		story_range_new.append(item)
		# adjust 
	return story_range_new

#txt range merge with shot range
def merge_shot(txtrange_1s, shots_range, leftrange, totalframes, fps):
	# add shots merging with 1s_txt range	
	#left_shotsrange_notoverlap = overlap.deleteoveralllap(shot_content["shots"], leftrange, totalframes)
	left_shotsrange_notoverlap = overlap.deleteoveralllap(shots_range, leftrange, totalframes)
	#left_shotsrange_sect = overlap.findintersection(left_shotsrange_notoverlap, leftrange)

	#### merge txt1s range and left shots range 
	story_range_list_1 = mergeRange.mergelist(txtrange_1s, left_shotsrange_notoverlap)
	story_range_list_2 = overlap.findDilateIntersection(story_range_list_1, txtrange_1s, left_shotsrange_notoverlap)
#	comm_log.info("merge txt1s range and left shots range")
#	print_c.print_list(story_range_list_2)
#	print_c.print_list_sec(story_range_list_2, fps*1.0)
	return story_range_list_2

def check_xinwen(video_path,zhuchiren_content, totalframes, fps):
	comm_log.info("check whether is xinwen video")
	story_list = [[0, totalframes-1]]
	story_second = [['{:.1f}'.format(i/float(fps)) for i in story_list[0]]]
	# not enough length, video length < 20 minutes
	if len(zhuchiren_content) <1200:
		comm_log.info("img len = "+str(len(zhuchiren_content)))
		comm_log.info("Not xinwen video. ")
		return False, story_list, story_second
	# not enough zhuchiren, zhuchiren < 2 minutes
	b = str(zhuchiren_content)
	if b.count("'zhuchiren'") < 120:
		comm_log.info("zhuchiren len = "+str(b.count("'zhuchiren'")))
		comm_log.info("Not xinwen video. ")
		return False, story_list, story_second
	return True, [], []

def makefolder():
	tv_folder = "./tv"
	if os.path.exists(tv_folder)==False:
	    os.makedirs(tv_folder)
	else:
	    shutil.rmtree(tv_folder)
	    os.makedirs(tv_folder)
	tv_folder = "./notv"
	if os.path.exists(tv_folder)==False:
	    os.makedirs(tv_folder)
	else:
	    shutil.rmtree(tv_folder)
	    os.makedirs(tv_folder)
	return

def out_others(totalframes, fps):
	story_list = [[0, totalframes-1]]
	story_second = [['{:.1f}'.format(i/float(fps)) for i in story_list[0]]]
	return story_list, story_second


# 识别的主体函数
def story_range(vid,video_path, imgfolder, shotsimgfolder, sound_content, txt1s_content, txtshots_content, shot_content, zhuchiren_content, totalframes, fps=15.0):
	s1 = time.time()
	flag, story_list, story_second = check_xinwen(video_path,zhuchiren_content, totalframes, fps)
	if flag == False:
		return story_list, story_second
	s2 = time.time()
	# folder for save tv and notv recog result
	makefolder()

	#load shots info and assecrt info
	flag, txt1s_content = assert_info.assert_1stxt(txt1s_content, fps, "second") 
	comm_log.info("assert sound. ")
	flag, sound_content = assert_info.assert_sound(sound_content, vid)
	s3 = time.time()
	flag_black, bbox = True, [] #detect_videoblack(vid)

	# txtrange_1s: 1s_txt range || contentjs_shots_txt: shots_txt_range
	comm_log.info("process text range. ")
	txtrange_1s, leftrange, contentjs_shots_txt, tvrangelist = processtxt(txt1s_content, vid, txtshots_content, zhuchiren_content, imgfolder, shotsimgfolder, totalframes, fps, shot_content, bbox)
	comm_log.info("1s ocr range: "+str(txtrange_1s)+" tvrangelist: "+str(tvrangelist))
	if txtrange_1s==[] or tvrangelist==[]: # e.g. 1 shot 
		return out_others(totalframes, fps)

	txtrange_1s_cp = copy.deepcopy(txtrange_1s)

	s4 = time.time()
	
	# following: txt range merge with shto and audio range
	story_range_list_2 = merge_shot(txtrange_1s, shot_content["shots"], leftrange, totalframes, fps)
	leftrange = overlap.leftpatch(story_range_list_2, totalframes, dist=1) 
	s5 = time.time()

	if sound_content is not None:
		story_range_list_2 = mergeSoundTxt.merge_soundtxt(story_range_list_2, sound_content, vid, fps,totalframes)

	#story_range_list = story_range_list_2 #merge_audio(story_range_list_2, sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=0.99,yingao=1000)
	story_range_list = merge_audio(story_range_list_2, sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=0.99,yingao=1000)
	s6 = time.time()

	story_range_list = check.checkError(story_range_list, totalframes, fps)
	story_range_list = check_storyrange_byocr(story_range_list, txtrange_1s_cp, tvrangelist,totalframes)


	# 1
	audio = audio_pause.CheckAudio(video_path, fps)
	for index in range(0):
		#flag = check_story(story_range_list, sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=0.8)
		if index==0:
			mode="long"
		else:
			mode="short"
		story_range_list = check_story_bydist(story_range_list, audio, fps, mode=mode, index = index)
		leftrange = overlap.leftpatch(story_range_list, totalframes, dist=1)
		story_range_list = merge_shot(story_range_list, shot_content["shots"], leftrange, totalframes, fps)
		# end
	s7 = time.time()
	
	comm_log.info("after all check audio")
	comm_log.info(str(story_range_list))

	#story_range_list  = check_headtoe(story_range_list, tvrangelist)
	#story_range_list = checkLast(story_range_list, tvrangelist,totalframes)
	story_range_list, story_range_list_str = check_result_boundary(story_range_list, fps)


	comm_log.info("check xinwen cost_time = %s\n assert txt cost_time = %s\n process txtrange cost_time = %s \
		 merge txtrange with shotrange cost_time = %s\n merge lastrange with audiorange cost_time = %s \
		check error and check audio cost_time = %s"%(str(s2-s1), str(s3-s2), str(s4-s3), str(s5-s4), str(s6-s5), str(s7-s6)))

	#输出list格式的结果，
	#story_range_list 帧为单位，
	#story_range_list_str  秒为单位（保留一位小数点

	comm_log.info("frame vid = "+vid+"  story frame_range= "+str(story_range_list) +" second_range= "+str(story_range_list_str))
	comm_log.info("shotsimgfolder=%s  totalframes=%s"% (str(shotsimgfolder), str(totalframes)))
	#comm_log.info("zhuchiren_content="+str(zhuchiren_content))
	saveFileresult(story_range_list, story_range_list_str, vid)

	return story_range_list, story_range_list_str

def saveFileresult(story_range_list, story_range_list_str, vid):
	story={}
	story[vid]={"frame_story_range":story_range_list,"sec_story_range":story_range_list_str}
	json.dump(story, open("./json/fileresult/"+vid+"_storyresult.json",'w'))

def checkLast(story_range_list, tvrangelist,totalframes):
	last = story_range_list[-1]
	


def check_headtoe(story_range_list, tvlist):

	str_range = str(story_range_list[:3])
	str_tv = str(tvlist)
	#for item in story_range_list:
	return 



#check bounday 
def check_result_boundary(story_range_list, fps):
	sec_story_range_list = []
	ccc = []
	num=0
	for item in story_range_list:
		num+=1
		#if num!=1 and item[0]+fps*0.1 < item[1]:
		#	item[0]+=int(fps*0.1)

		# end adjust 
		#item[1]-=fps
		item_tmp = (np.array(item)/float(fps)).tolist()
		sec_story_range_list.append(item_tmp)
		cc = ['{:.2f}'.format(i) for i in item_tmp]
		ccc.append(cc)
	return story_range_list, ccc

# clip audio range again
def check_audio(story_range_list, audio, fps, mode, index):
# mode = short, long
	#obj = audio_pause.find_max_silence()
	#if index>4:
	#	index = 4

	last_item = story_range_list[0]
	num = 0
	gap_num = 0
	new_s = []
	leng, clip_t = -1, -1
	for item in story_range_list:
		num+=1
		if num==1:
			continue
		if item[0] - last_item[1] > 1.1*fps:
			gap_num+=1
			# default regard: 1 story duration time >3.5 seconds
			# indent 3.5s to avoid clip on boundary
			if mode=="long":
				if (last_item[1]-fps*4.5 > last_item[0]) and (item[0]+fps*4.5 < item[1]):
					leng, clip_t = audio.find_max_silence(last_item[1]-fps*4.5, item[0]+fps*4.5, pitch_threshold=850)	
				else:
					leng, clip_t = audio.find_max_silence(last_item[1]-fps*2.5, item[0]+fps*2.5, pitch_threshold=850)	
			else:
				leng, clip_t = audio.find_max_silence(last_item[1]-fps*1.5+fps*index*0.1, item[0]+fps*1.5-fps*index*0.1, pitch_threshold=850)	
			if item[0]+fps*2.0 >= clip_t >= last_item[1]-fps*2.0: 
				comm_log.info("longest silence = "+str(leng)+" and relative_pos = "+str(clip_t-last_item[1]))
				#comm_log.info(last_item)
				if mode == "short":
					last_item[1]=clip_t-0.5*fps+fps*index*0.1 #+leng/2-1
				else:
					last_item[1]=clip_t-2.5*fps #+leng/2-1
				new_s.append(last_item)
				#new_s.append([clip_t+1, item[1]])
				#if clip_t+leng/2-1 < item[1]:
				if clip_t+leng+2.5*fps < item[1] and mode=="long":
					#last_item = [clip_t+leng/2-1, item[1]]
					last_item = [clip_t+leng+2.5*fps, item[1]]
				elif clip_t+leng+0.5*fps < item[1] and mode=="short":
					#last_item = [clip_t+leng/2, item[1]]
					last_item = [clip_t+leng+0.5*fps-fps*index*0.1, item[1]]
				else:
					comm_log.info("error. too short story range")
				continue
		new_s.append(last_item)
		last_item = item
	new_s.append(last_item)
	return new_s

# find whether thers's more than 2 seconds left.
def check_story_bydist(story_range_list,audio, fps, mode, index):
	#last_item = story_range_list[0]
	#num = 0
	#gap_num = 0
	#for item in story_range_list:
	#	num+=1
	#	if num==1:
	#		continue
	#	if item[0] - last_item[1] > 2.5*fps:
	#		gap_num+=1
	#		#clip_t = audio_pause(video_path, last_item[1], item[0])	
	#		
	#	last_item = item
	#comm_log.info("story gap>2.5fps _num = "+str(gap_num))
	#if gap_num > 3:
	#	# higher threshold, less nums of audio ranges
	#	story_range_list = merge_audio(story_range_list,sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=0.80, yingao=800)

	comm_log.info("before check audio:")
	comm_log.info(str(story_range_list))
	new_story_range_list = check_audio(story_range_list, audio, fps, mode, index)
	comm_log.info("after check audio:")
	comm_log.info(str(new_story_range_list))


#	elif gap_num > 2:
#		story_range_c = merge_audio(story_range_list,sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=0.6)
#		return story_range_c
#	elif gap_num > 1:
#		story_range_c = merge_audio(story_range_list,sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=0.7)
#		return story_range_c
	return new_story_range_list
	#return story_range_list


def merge_audio(story_range_list_2,sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=0.8, yingao=1000):
	audiorange, last_range_list = makeSoundRange(sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold=threshold, yingao=yingao)
	#comm_log.info("audio range :")
	print_c.print_list_sec(audiorange, fps*1.0)
#
#	#### add audio mergin with before range
	leftrange2 = overlap.leftpatch(story_range_list_2, totalframes, dist=1) 
	left_audiorange_notoverlap = overlap.deleteoveralllap(audiorange, leftrange2, totalframes)
#	#left_audiorange_sect = overlap.findintersection(left_audiorange_notoverlap, leftrange2)

	story_range_list_31 = mergeRange.mergelist(story_range_list_2, left_audiorange_notoverlap)
	story_range_list_3 = overlap.findDilateIntersection(story_range_list_31, story_range_list_2, left_audiorange_notoverlap)
#	print_c.print_list(story_range_list_3)
#	print_c.print_list_sec(story_range_list_3, fps*1.0)
	return story_range_list_3



def makeSoundRange(sound_content,video_path, shot_content, vid, txtrange_1s, tvrangelist, leftrange, fps,totalframes, threshold, yingao ):
	# if sound_conent is empty, then use audiostop 
	audiorange = []
	last_range_list = []
	if not sound_content:
		audiorange = processAudio(video_path,shot_content, vid, fps, threshold, yin_height=yingao)
	else:
		# txtrange_1s and soundrange_left, shotsrange_left not total overlap 	
		obj = processsound(vid, txtrange_1s, tvrangelist, leftrange, sound_content, shot_content, fps)
		soundrange_left, shotsrange_left, merge_range  = obj.loadsoundtext2(totalframes)

		last_range = tool.processstop(soundrange_left, shotsrange_left, merge_range, leftrange)
		comm_log.info("left range ---- post-process merge all sound and shots range_left: ")
		comm_log.info(str(last_range))
		for item in last_range:
			last_range_list += item
		comm_log.info(str(last_range_list))

		txtrange_1s_cp = copy.deepcopy(txtrange_1s)
		last_range_left = copy.deepcopy(last_range_list)
		audiorange = last_range_list
	return audiorange, last_range_list
#	# merge sound+leftrange and shots+leftrange and txtrange
#	#tmp = txtrange_1s + last_range_list + audiorange
#	tmp = txtrange_1s + last_range_list + audiorange
#	obj = MergeRange()
#	story_range_list = obj.merge(tmp)



def getshotsocr(vid,image_path,ext={}):
	ocr_sid_port = ext.get("ocr_sid_port", "65:1081344")
	threath_num = ext.get("threath_num", 10)
	dup_tag = ext.get("dup_tag",-1)
	comm_log.info(
		"CheckOcrTxt ext ocr_sid_port[%s] threath_num:[%d] dup_tag[%d]" % (ocr_sid_port, threath_num, dup_tag))
	ocr_result = OcrCheckTools.getOcrResult(vid,image_path,ocr_sid_port, threath_num, dup_tag)
	add_result = []
	for row in ocr_result:
		txt_list = []
		image_path = row['path']
		length = 0
		for key in row['txt']:
			length += len(row['txt'][key]['txt'].encode("utf-8"))
			txt_list.append(row['txt'][key]['txt'].encode("utf-8"))
		#comm_log.info("CheckOcrTxt[%s],[%s],[%s]" % (vid, image_path, "".join(txt_list)))
		if length > 0:
			add_result.append(row)
	return add_result,{}
def makeShotContent(vid,shot_content):
	#result = {"vid"'shots':shot_content['shots']}
	result = {}
	result[vid] = {"shots":shot_content['shots']}
	return result
def getStoryRange(vid,video_path,shot_content,txt1s_content,zhuchiren_content,sound_content,imgfolder, shotsimgfolder):
	#load shots info and assert info
	s1 = time.time()
	flag, shot_content =  assert_info.assert_shotsinfo(shot_content, vid)
	s2 = time.time()
	#flag, txt1s_content = assert_1stxt(txt1s_content, fps, "second") 
	txt1s_content_bak = copy.deepcopy(txt1s_content)
	for _ in range(3):
		txt1s_content = txt1s_content_bak
		try:
			shots_frame_folder = None
		        cap = cv2.VideoCapture(video_path)
		        fps=float(cap.get(cv2.CAP_PROP_FPS))
		        comm_log.info("-fps = "+str(fps))
			if fps==0.0:
				continue
			#shot_content_info = makeShotContent(vid,shot_content)
			shots_frame_folder, totalframes, fps = getshots_img.getshots_img(video_path, shot_content, vid,shotsimgfolder)
			s31 = time.time()
			comm_log.info("before story_range: get shot img cost_time = %s"%(str(s31-s2)))
			if totalframes<fps*20*60:
				comm_log.info("No process too short video. vid="+str(vid)+" totalframes="+str(totalframes))
				story_list = [[0, totalframes-1]]
				story_second = [['{:.1f}'.format(i/float(fps)) for i in story_list[0]]]
				return {"sec_shots":story_second,"shots":story_list}
			if totalframes>fps*50*60:
				comm_log.info("No process too long video. vid="+str(vid))
				story_list = [[0, totalframes-1]]
				story_second = [['{:.1f}'.format(i/float(fps)) for i in story_list[0]]]
				return {"sec_shots":story_second,"shots":story_list}
			txtshots_content, zhuchiren_content_shots = getshotsocr(vid,shots_frame_folder)
			s3 = time.time()
			comm_log.info("before story_range: get shot ocr data cost_time = %s"%(str(s3-s31)))
			#print txtshots_content
			frame_range, sec_range = story_range(vid,video_path, imgfolder,shotsimgfolder, sound_content, txt1s_content, txtshots_content, shot_content,zhuchiren_content, totalframes, fps)
			s4 = time.time()
			print frame_range
			comm_log.info("assert shotinfo cost_time = %s\n \
				before story_range: get shot img and shot ocr data cost_time = %s\n \
				story main cost_time = %s "%(str(s2-s1),str(s3-s2), str(s4-s3)))

			saveresult(frame_range, video_path, vid)
			comm_log.info("sec_shots= "+str(sec_range)+"   shots="+str(frame_range))

			return {"sec_shots":sec_range,"shots":frame_range}
		except Exception as e:
			comm_log.error(str(e))
			comm_log.error(traceback.format_exc())
			comm_log.info(traceback.format_exc())
		finally:
			pass

		# cannot process
		return None


if __name__ == '__main__':
	video_path = sys.argv[1]
	sound_content = sys.argv[2]
	txt1s_content = sys.argv[3]
	shot_content = sys.argv[4]
	zhuchiren_content_1s = sys.argv[5]
	vid = sys.argv[6]
	fps =sys.argv[7] 

	# get shots imgs
	shots_frame_folder = getshots_img.getshots_img(video_path, shot_content, vid)
	# something to do 
	# get ocr results for shots img
	txtshots_content, zhuchiren_content_shots = getshotsocr(shots_frame_folder)

	zhuchiren_content = zhuchiren_content_1s

	#识别事件
	frame_range, sec_range = story_range(vid,video_path, imgfolder, shotsimgfolder, sound_content, txt1s_content, txtshots_content, shot_content, zhuchiren_content, totalframes, fps)
	#video_path = "xinwen2/video/"+vid 
	#保存结果
	saveresult(frame_range, video_path, vid)

