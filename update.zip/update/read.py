import sys,os

for line in open(sys.argv[1]): 
		gen = str(line.strip())
		print("cp "+gen+" notxt/")

