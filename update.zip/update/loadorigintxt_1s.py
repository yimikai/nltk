# -*- coding: utf-8 -*-
import os,sys
from PIL import Image
import json
import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
reload(sys) 
sys.setdefaultencoding('utf8')
sys.path.append("./pyscripts/")

from PIL  import Image, ImageDraw
from getcolor import *
import re
import string
from mergeRange import *
from loadorigintxt import *
from SummaryRange import *
from tool import * 
import postprocess_txt as postp_txt
import check
import pyscripts.comm_log as comm_log

def savetv(flag0, value, imgpath, tvlist, diqiurange, index):
	cmd = ""
	if flag0==True:
		cmd = "cp "+ imgpath +" tv/"
		print(cmd)
		if value=="zhuchiren":
			tvlist.append(index)  
		else:
			diqiurange.append(index)
	else: #if flag0==True:
		cmd = "cp "+ imgpath +" notv/"
	flag11 = run_shell(cmd)
	return tvlist, diqiurange

def loadtext_1s(txt_dict,vid, zhuchiren_content, imgfolder, fps, totalframes, bbox):
	out=[]
	tvlist = []
	out_txt={}

	out_range={}
	tmp_txt={}
	txtstop_list = []
	subtxt_range = []
	min_subtxt =1000000
	max_subtxt = 0
	last_subtxt = ""
	lastpatch=[]
	
	count=-1
	print("txt1s content:"+str(txt_dict))
	diqiurange = []
	zhuchi2_range = []
	for content in sorted(txt_dict,key=lambda content:int(content["path"].split(".jpg")[0]),reverse=False):
		try:
			print("---for 1 img-----"+content["path"])
			# transfer frame to second 
			index = int(content["path"].split(".jpg")[0])
			second = int(index - math.ceil(fps/2))/fps+1 
			imgpath = imgfolder + str(second) + ".jpg"
		        if os.path.exists(imgpath)==False:
		        	print("warning: NO img: "+ str(imgpath))
				continue
				#return [], [],{}
			print(imgpath +" exist.")
			img = Image.open(imgpath)
##
				
			img, w, h, scale_w, scale_h = check.checkImgScale(img)
			flag0, value = television(str(second)+".jpg",vid, "1s", zhuchiren_content)
			tvlist, diqiurange = savetv(flag0, value, imgpath, tvlist, diqiurange, index)
	
			text_dict = content["txt"]
			content_txt=""
			tag_content = "-1"
			for key in text_dict.keys(): #key is order index, meaning how many text-lines 
			    line_text_dict = text_dict[key]
			    line_box_i = line_text_dict['line_box']
			    content_txt = line_text_dict['txt'].strip()

			    print("1s_ocr:  index="+str(index) + " "+str(line_text_dict)+" txt= "+str(content_txt))
			
			    #flag, tag, height, width = subtxt(line_box_i, img, scale_w, scale_h, index)
			    flag, tag, height, width = subtxt0(line_box_i, img, scale_w, scale_h, index, w, h ,bbox)
			    if flag!="":
			        content_txt = "".join(content_txt.split())
			        content_txt = ''.join(re.findall(u'[\u4e00-\u9fff]+', content_txt))
			
			    	if flag=="2zhuchi":
			    	    zhuchi2_range = save2zhuchi(zhuchi2_range, second, content_txt)
			            continue

				# for biaoti 

			        tag_content=tag
			        print(imgpath + " height= "+str(height) +" color= "+str(tag)+" txt= "+str(content_txt))
			        count+=1
			        if content_txt=="":
			            continue
			
			        #if (count==0) and (tag=="blue") and (height==20 or height==24):
		                #if (count==0) and (tag=="blue") and (25< height<38):
		                if (count==0) and (tag=="blue") and (14< height<38 or (30< height<80 and (w==1920 or w==864))):
			            last_subtxt = content_txt
			            break #
			
			        #if (tag=="blue") and (height==20 or height==24 or abs(height-18)<2): # record subtxt 
		                #if (tag=="blue") and (24< height<40): # record subtxt 
		                if (tag=="blue") and  ((14< height<38) or (30< height<80 and (w==1920 or w==864))): # record subtxt 
			            min_subtxt,max_subtxt, last_subtxt, subtxt_range, tmp_txt = find_range(content["path"], min_subtxt, max_subtxt, last_subtxt, content_txt, subtxt_range, tmp_txt, index)

			            print("last txt   :"+str(last_subtxt))
			            print("current txt:"+str(content_txt))
			            break
			
			#out_txt[content['path']]={"txt":content_txt,"tag":tag}
			out_txt[content['path']]={"txt":content_txt,"tag":tag_content}
		except Exception as e:
			print(str(e))
			print(traceback.format_exc())
			continue
        		#raise Exception(str(e))
	
	try:
		# save last subtext
		if min_subtxt < max_subtxt:
			tmp_txt[last_subtxt]=[min_subtxt, max_subtxt]
			subtxt_range.append([min_subtxt, max_subtxt])
		
		
		print("1s tvlist: "+str(tvlist))
		print("1s_ocr: "+str(subtxt_range))
		if len(subtxt_range)==0:
			return [], tvlist, diqiurange,zhuchi2_range,out_txt #txtstop_list
		
		out = postp_txt.postprocess_txt(tmp_txt, fps, totalframes)
		
		out_range['range']=out
		return out, tvlist, diqiurange,zhuchi2_range,out_txt #txtstop_list
	except Exception as e:
		print(str(e))
		print(traceback.format_exc())
        	raise Exception(str(e))
	
	comm_log.info("zhuchi2_range = "+str(zhuchi2_range))
	return out, tvlist, diqiurange, zhuchi2_range, out_txt #txtstop_list

		# 从序列中找到片段
# default fps = 15
# tv_1s : every second tv_recog result, and only record tv index
def processtvlist(tv_1s, totalframes, fps=15):
	tlist0 = np.array(tv_1s)/fps+1
	tlist1 = tlist0.tolist()
	print("second tvlist:")
	print(tlist1)
	obj = SummaryRange()
	tlist2 = obj.summaryRanges(tlist1)
	print("second tvrange:")
	print(tlist2)

	tlist3 = []
	for item in tlist2:
		if (len(item)==2)and (item[1]-item[0])>=2:
			tlist3.append(((np.array(item)-1)*fps+math.ceil(fps/2)).tolist())
	print("after processtvlist:")
	print(tlist3)
	#set first and last frame
	if (tlist3!=[]) and (totalframes>1):
		tlist3[-1][1]=totalframes-1
		


	if (tlist3!=[]):
		tlist3[0][0]=0
	if (tlist3==[]): # no continous range
		tlist3new = []
		for i in range(len(tv_1s)):
			tlist3new.append([tv_1s[i],tv_1s[i]])
		return False, tlist3new
	return True, tlist3

def mergeBy2zhuchi(rangetxt_all, zhuchi2_framerange):
	interrange = findintersection(rangetxt_all, zhuchi2_framerange)
	if interrange==[]:
		comm_log.info("zhuchiren2 intersection with txtrange_all == [] ")
		rangetxt_all.insert(0,zhuchi2_framerange)
	return rangetxt_all

def splitbyEarth(rangetxt_all, diqiurange_frame):
	range_new = []
	num=-1
	last_index = -1
	for item in rangetxt_all:
		num+=1
		interrange = findintersection(item, diqiurange_frame)
		if interrange!=[]:
			index = num 
			if last_index!=-1 and (index-last_index==1):
					range_new[-1][1]=laprange[1]
			last_index = index
		range_new.append(item)
		
#	for item in diqiurange_frame:
#		flag, laprange =  overlap.overalllap(item, rangetxt_all)
#		if flag==True:
#			if len(laprange)>1:
#				laprange_new = [laprange[0][0], laprange[-1][1]]
#				range_new.append(laprange_new)
#				last_index = rangetxt_all.index(laprange[-1])
#			else:
#				index = rangetxt_all.index(laprange) 
#				if last_index!=-1 and (index-last_index==1):
#					range_new[-1][1]=laprange[1]
#				last_index = index

	return range_new 

def processtxt(txt1s_content, vid, txtshots_content,zhuchiren_content, imgfolder, shotsimgfolder, totalframes, fps, shot_content, bbox):
		rangetxt_1s, tv_1s, diqiurange, zhuchi2_range, tmp = loadtext_1s(txt1s_content, vid, zhuchiren_content, imgfolder, fps, totalframes, bbox)
		# 从序列中找到片段
		flag, rangetv_1s = processtvlist(tv_1s, totalframes, fps)
		#flag, diqiurange_frame = processtvlist(diqiurange, -1, fps)
		flag, zhuchi2_framerange = findSummaryRange(zhuchi2_range, fps)
		comm_log.info("1s_tv_range:" +str(rangetv_1s))
		comm_log.info("diqiurange= "+str(diqiurange))
		#comm_log.info("after process diqiurange= "+str(diqiurange_frame))
		
		obj = Loadshotstxt()
		rangetxt_all, leftrange, contentjs_shots_txt, tvrange_list = obj.combine_txt_tv(txtshots_content, vid, rangetxt_1s, rangetv_1s,zhuchiren_content, shotsimgfolder, totalframes, shot_content, fps, bbox)
		comm_log.info("before split by earth: " +str(rangetxt_all))
		#rangetxt_all  = splitbyEarth(rangetxt_all, diqiurange_frame)
		rangetxt_all  = mergeBy2zhuchi(rangetxt_all, zhuchi2_framerange)
		rangetxt_all = check.checkError(rangetxt_all, totalframes, fps)
		#comm_log.info("after split by earth: " +str(rangetxt_all))
		
		return rangetxt_all, leftrange, contentjs_shots_txt, tvrange_list




if __name__ == '__main__':
	txtpath = sys.argv[1]
	vid = sys.argv[2]
	shotstxtpath = sys.argv[3]
	
	txtrange, contentjs_shots_txt, tvrange_list = processtxt(txtpath,vid,shotstxtpath)
