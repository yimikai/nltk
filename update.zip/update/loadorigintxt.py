# -*- coding: utf-8 -*-
import os,sys
from PIL import Image
import json
import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
reload(sys) 
sys.setdefaultencoding('utf8')
sys.path.append("./pyscripts/")

from PIL  import Image, ImageDraw
from getcolor import *
import re
import string
from mergeRange import *
import mergeRange
from Classify import *
import subprocess
#from  make_soundstop import *
from SummaryRange import *
import copy
import math
from tool import * 
from loadtxt import *
from IntervalIntersection import *
import overlap
import check

class Loadshotstxt():
	def __init__(self):
	    pass
	
	def process_tvlist(self, tvlist, txt_range):
		#delete tv in txtrange, regard this range as error recog tv images, so delete it.
		tvlist2=[]
		for item in tvlist:
			if inrange_txt(item,txt_range)==False:
				tvlist2.append(item)
		
		print(" delete tv in txtrange, left tvlist2")
		print(tvlist2)
		
		# find continue range: len==3, i.e. item[1]-item[0]==2
		obj2 = SummaryRange()
		tvlist3 = obj2.summaryRanges(tvlist2)
		tvlist4=[]

		for item in tvlist3:
			if (len(item)==2) and (item[1]-item[0]==2):
				tvlist4.append(item)
		print("delete not continous tv, left tvlist4:")
		print(tvlist4)
		return tvlist4

	#combine tv scene and txtrange, 
	#retuturn tvlist4 : tv continous patch
	def process_tv_txt(self, tvlist4, txt_range):
		#1
		txt_range3 = mergeRange.mergelist(txt_range, tvlist4)
		print("merge txt_range and tvlist4: ")
		print(txt_range3)

		#2
		last_item = txt_range3[0]
		count = -1 
		txt_range4 = []
		txt_range4.append([0,txt_range3[0][0]-3])

		for item in txt_range3:
			count += 1
			if count == 0:
				txt_range4.append(item)
				continue 
			if (last_item[1]-last_item[0] == 2) and (item[1] -item[0]>2): # zhuchiren and txtrange
				txt_range4[-1][1]=item[1]
				last_item = txt_range4[-1] 
				continue
			
			if (last_item[1]-last_item[0] > 2) and (item[1] -item[0]==2): # txtrange and zhuchiren
				maxtmp = last_item[1]
				if item[0]-3 > last_item[1]:
					maxtmp = item[0]-3
				txt_range4[-1][1] = maxtmp
				txt_range4.append(item)
				last_item = item 
				continue
			
			txt_range4.append(item)
			last_item = item 
		print("after combine zhuchiren and  txt_range")
		print(txt_range4)

		#3: delete zhuchiren shots range, only record txtrange
		print("after delete tv shots range, only record txtrange")
		txt_range5 = []
		for item in txt_range4:
			if item[1]-item[0] != 2: # not tv image
				txt_range5.append(item)
		print(txt_range5)

		print("04: tvlist4:")
		print(tvlist4)
		return txt_range5 

	# frame-level :combine all tv_patch  and  all txtrange, tvpatch has benn merged with shot info
	def process_tv_txt2(self, tvlist4, txt_range):
		if (not tvlist4) and (not txt_range):
			return []

		tvlist4_cp = copy.deepcopy(tvlist4)
		txtrange_cp = copy.deepcopy(txt_range)
		#1
		txt_range3 = mergeRange.mergelist(txt_range, tvlist4)

		str_tvlist5, str_txt_range = str(tvlist4_cp), str(txtrange_cp)
		#2
		last_item = txt_range3[0]
		count = -1 
		txt_range4 = []
		txt_range4.append([0, txt_range3[0][0]-3])

		for item in txt_range3:
			count += 1
			if count == 0:
				txt_range4.append(item)
				continue 
			# last is zhuchiren and current is subtxt
			if (str(str_tvlist5).find(str(last_item[1]))!=-1) and (str_txt_range.find(str(item[0]))!=-1): # zhuchiren and txtrange
				txt_range4.append([last_item[1]+3,item[1]])
				last_item = [last_item[1]+3,item[1]] 
				continue
			
			if (str(str_tvlist5).find(str(item[0]))!=-1) and (str_txt_range.find(str(last_item[1]))!=-1): # txtrange adn zhuchiren
				maxtmp = last_item[1]
				if item[0]-3 > last_item[1]:
					maxtmp = item[0]-3
				txt_range4[-1][1] = maxtmp
				txt_range4.append(item)
				last_item = item 
				continue
			
			txt_range4.append(item)
			last_item = item 
		print("after combine zhuchiren and  txt_range")
		print(txt_range4)

		return txt_range4 


	# second-level :combine all tv_patch  and  all txtrange, tvpatch hasnot been merged with shot info
	# assume: 2.5fps between zhuchiren and next story to make sure zhuchiren image maybe not recognized.because only 1 frame recognized for 1 second.
	def process_tv_txt1(self, tvlist4, txt_range, fps):
		if (not tvlist4) and (not txt_range):
			return []

		print("before combine zhuchiren and  txt_range")
		print("txtrange:")
		print(txt_range) 
		print("tvlist4:")
		print(tvlist4)

		tvlist4_cp = copy.deepcopy(tvlist4)
		#txtrange_cp = copy.deepcopy(txt_range)
		str_tvlist5, str_txt_range = str(copy.deepcopy(tvlist4)), str(copy.deepcopy(txt_range))
		#1
		txt_range3 = mergeRange.mergelist(txt_range, tvlist4_cp)

		#2
		last_item = txt_range3[0]
		count = -1 
		txt_range4 = []
		txt_range4.append([0, txt_range3[0][0]-3])

		for item in txt_range3:
			count += 1
			if count == 0:
				txt_range4.append(item)
				continue 
			# last is zhuchiren and current is subtxt
			if (str(str_tvlist5).find(str(last_item[1]))!=-1) and (str_txt_range.find(str(item[0]))!=-1): # zhuchiren and txtrange
				txt_range4.append([last_item[1]+fps*2.5,item[1]])
				last_item = [last_item[1]+fps*2.5,item[1]] 
				continue
			
			if (str(str_tvlist5).find(str(item[0]))!=-1) and (str_txt_range.find(str(last_item[1]))!=-1): # txtrange adn zhuchiren
				maxtmp = last_item[1]
				if item[0]-2.5*fps > last_item[1]:
					maxtmp = item[0]-2.5*fps
				txt_range4[-1][1] = maxtmp
				txt_range4.append(item)
				last_item = item 
				continue
			
			txt_range4.append(item)
			last_item = item 
		print("after combine zhuchiren and  txt_range")
		print(txt_range4)
		return txt_range4 


	# leftpatch add shots patch
	def leftpatch2_shots(self, leftrange, shotsrange):
		obj = IntervalIntersection()
		section = obj.intervalIntersection(leftrange,shotsrange)
		return section

	def intersection_tv_shot(self, tv_list_all,shot_content):
		clip_list = shot_content["shots"]
		obj = IntervalIntersection()
		section = obj.intervalIntersection(tv_list_all,clip_list)
		return section

	def adjust_add(self, tv_list_all, patch=10):
		tlist = []
		for item in tv_list_all:
			tlist.append((np.array(item)+patch).tolist())
		return tlist
	def delete_trivial(self, tv_list_all):
		tv_list_new = []
		for item in tv_list_all:
			if item[1]-item[0]<3:
				#tv_list_all.remove(item)
				continue
			tv_list_new.append(item)
		return tv_list_new
	def print_tmp(self,list_t, fps):
		for item in list_t:
			a=(np.array(item)/fps).tolist()
			print(a)
	def mergetxt_1s_shottxt(self, txt, rangetxt_1s, totalframes, fps):
		txt_list_all = mergeRange.mergelist(txt, rangetxt_1s) 
		txt_list_all = check.checkError(txt_list_all, totalframes, fps)
		print("--merge 1s and shots txt--")
		print(txt_list_all)
		return txt_list_all
	# all tv range, and differ 2 zhuchiren 
	def merge_tv(self, tvlist, rangetv_1s, shot_cp, totalframes, fps):
		tv_list0 = mergeRange.mergelist(tvlist, rangetv_1s) 
		print("--merge 1s tv and shots tv--")
		print(len(tv_list0))
		print(tv_list0)
		# differ 2 zhuchiren 
		tv_list = overlap.splitbyshot(tv_list0, shot_cp, totalframes, fps)
		print("--split tv_list by shot  to differ zhuchiren--")
		print(len(tv_list))
		print(tv_list)
		print("--shot range --")
		print(shot_cp)
		return tv_list
	# kuochogn tv range by shot
	def merge_tv_shot(self, tv_list, shot_cp):
		tmp = mergeRange.mergelist(shot_cp, tv_list) 
		tv_list_all = overlap.findDilateIntersection(tmp, tv_list, shot_cp)
		tv_list_all_2 = self.delete_trivial(tv_list_all=tv_list_all)
		print("--kuochong zhuchiren --")
		print(len(tv_list_all_2))
		print(tv_list_all_2)
		return tv_list_all_2

	def combine_txt_tv(self, txtshots_content, vid, rangetxt_1s, rangetv_1s, zhuchiren_content, shotsimgfolder, totalframes, shot_content, fps, bbox):
		txt, tvlist, tmp,txt_shots = loadtext(txtshots_content, vid, zhuchiren_content, shotsimgfolder, fps, totalframes, bbox)

		txt_list_all = self.mergetxt_1s_shottxt(txt, rangetxt_1s, totalframes, fps)

		# all tv range 
		shot_cp = copy.deepcopy(shot_content["shots"])
		tv_list = self.merge_tv(tvlist, rangetv_1s, shot_cp, totalframes, fps)
		# depreciated: merge tv and shot . Because shot clip is not 100% right.
		# TO DO: makr sure shot clip 100% right. 
		tv_list_all = self.merge_tv_shot(tv_list, shot_cp)
		#tv_list_all = tv_list #self.merge_tv_shot(tv_list, shot_cp)

		# for frame-level tv range
		txt_new = self.process_tv_txt2(tv_list_all, txt_list_all)
		# for second-level tv range
		#txt_new = self.process_tv_txt1(tv_list_all, txt_list_all, fps)
		self.print_tmp(list_t=txt_new,fps=fps)
		leftrange = overlap.leftpatch(txt_new, totalframes, dist=1)
		self.print_tmp(list_t=leftrange,fps=fps)
		return txt_new, leftrange, txt_shots, tv_list_all

if __name__ == '__main__':
    txtpath = sys.argv[1]
    vid = sys.argv[2]
    obj = Loadshotstxt()
    #txt, tvlist, out_txt = obj.loadtext(txtpath,vid)
    print("tvlist:")
    print(tvlist)
    print("tvrange:")
    print(txt)
    txt_new = obj.merge(tvlist,txt)
    print("txt_new")
    print(txt_new)
    #json.dump(txt, open(vid+"_subtxt_range_0819mergezhuchiren.json",'w'))
