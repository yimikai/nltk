import overlap 


def shot_leftrange(shots_range, leftrange, totalframes):
	# load shots range
	left_shotsrange_notoverlap = overlap.deleteoveralllap(shots_range, leftrange, totalframes)
	#intersection_range2 = self.findintersection(left_shotsrange_notoverlap, leftrange)
	return left_shotsrange_notoverlap
