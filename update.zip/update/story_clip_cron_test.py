# -*- coding: utf-8 -*-
import pyscripts.comm_log as comm_log
import argparse
import traceback
import json
import mysql_tool.MysqlHelper as mysql_help
import time
import os,sys
import random
import Queue, threading
import Tool.Tool as Tool
from configparser import ConfigParser
import shuping_ocr.OcrCheckTools as OcrCheckTools
import multiprocessing
import shot_comm as shot_comm
import story_clip_main2 as story_clip_main2
import pyscripts.post_result as post_result

def getArg():
    parser = argparse.ArgumentParser(description='params for python')
    parser.add_argument('--limit_num', type=int, default=10)
    parser.add_argument('--db_name', type=str, default="ocrsound_info")
    parser.add_argument('--config_file', type=str, default="./conf/conf.ini")
    return parser.parse_args()


def worker():
    video_list = shot_comm.selectList(conn)
    for row in video_list:
        vid = row[0]
        infostr = json.loads(row[1])
	framenum = infostr["framenum"]
	comm_log.info("framenum = "+str(framenum))
	if framenum > 50*60*24:
		continue
        create_time = row[2]
        shots_info = getInfo(vid, infostr, create_time)

def checkVideoStatus(vid,info_keys,create_time_int):
    comm_log.info("vid %s has_success_key %s"%(vid,str(info_keys)))
    if len(info_keys)<3:
        return False
    if "ocr" not in info_keys:
        comm_log.info("no ocr.")
        return False
    if "imglist" not in info_keys: 
        comm_log.info("no zhuchiren.")
        return False
    if "keyframe" not in info_keys: 
        comm_log.info("no shot.")
        return False
    return True
    #comm_log.info create_time_int;sys.exit()
    if "sound" not in info_keys and int(time.time())-create_time_int>2*60:
            comm_log.info("vid %s has not_sound but wait too long")
            return True
    comm_log.info("check video duration time = cur_t-create_time = "+str(int(time.time())-create_time_int))
    if "sound" not in info_keys: return False
    return True


def DownImage(image_url, vid, i, image_dir, timeout, resultQueue):
	url = "{}{}_{}.jpg".format(image_url, vid, i)
	result = {}
	result['down_result'], result['dcode'], result['error'] = Tool.Tool.dowUrl(url, "{}.jpg".format(i), image_dir,timeout)
	result['url'] = url;
	resultQueue.put(result)

def downImagethreading(vid, image_url, image_num,image_dir):
    resultQueue = Queue.Queue()
    result = []
    comm_log.info("vid {} stat down load url:{}".format(vid, image_url))
    starttime = time.time() * 1000
    # #monitor_add(494483, 1)
    # monitor_avge(494543, image_num)
    threading_list = []
    for i in range(1, int(image_num) + 1):
        my_thread = threading.Thread(target=DownImage,args=(image_url, vid, i, image_dir,10, resultQueue))
        threading_list.append(my_thread)

    for pross in threading_list:
        while True:
            if (len(threading.enumerate()) < 100):
                comm_log.info("DownImagethreading num:" + str(len(threading.enumerate())))
                break
        pross.start()

    for pross in threading_list:
        pross.join()

    while not resultQueue.empty():
        info = resultQueue.get()
        #comm_log.info(info)
        result.append(info)

    endtime = time.time() * 1000
    costtime = (endtime - starttime)  # 微秒 1000微秒=1毫秒
    comm_log.info("end down load vid:" + vid + " cost time:" + str(int(costtime)))
    # monitor_avge(494519, int(costtime / 1000))
    return result


def dealResult(result):
    # {"framenum":34,"moduleid":41,"picdir":"/om/original/20181105/000/","storageip":"100.115.152.166","vid":"p07832ax25z","sindex":2,"offset":3,"audiodir":"/om/20181105/000/","audio_format":"aac"}
    #comm_log.info(str(result))
    vid = result["vid"]
    storageip = result["storageip"]
    image_url = "http://{}{}".format(storageip, result['picdir'])
    image_num = result['framenum']
    return image_url, image_num, storageip

def getInfo(vid, infostr, create_time):
    save_info = {}
    save_info['vid'] = vid
    create_time_int = int(time.mktime(create_time.timetuple()))
    comm_log.info("vid %s create_time %s"%(vid,create_time))
    base_detail = shot_comm.getBaseDetail(conn,vid)
    info = {}
    for row in base_detail:
        row_type = row[2]
        txt = row[1]
        if txt != None:
            info[row_type] = json.loads(txt)
    st_time = time.time()
    check_detail = checkVideoStatus(vid,info.keys(),create_time_int)
    st2 = time.time()
    comm_log.info("tag 1: checkvideostatus cost_time = "+str(st2-st_time))
    if check_detail==False:
        comm_log.info("vid %s detail not satisfy %s"%(vid,str(info.keys())))
        return
    start_time = int(time.time()*1000)
    video_path=image_dir=shots_image_dir=None
    try:
        url = infostr['url']
        video_path = "./video_base/%s/"%vid
        image_dir = "./image_dir/%s/"%vid
        shots_image_dir = "./shots_image_dir/%s/" % vid
        if os.path.exists(video_path)==False:os.makedirs(video_path)
        if os.path.exists(video_path) == False: os.makedirs(image_dir)
        if os.path.exists(shots_image_dir) == False: os.makedirs(shots_image_dir)
        image_url, image_num, ip = dealResult(infostr)
        comm_log.info(str(image_url)+", "+ str(image_num) + ", "+str(ip));
        down_result, down_code, message = Tool.Tool.dowUrl(str(url).split('?')[0],"%s.mp4"%vid,video_path,30)
        if down_result == False:
            comm_log.info("%s  url %s false %s" % (vid, url, message))
            shot_comm.updateBaseInfoEnd(conn,vid,shot_comm.EDN_VIDEO_ERRROR)
            return
        st3 = time.time()
        comm_log.info("tag 1: load video cost_time = "+str(st3 - st2))

        down_image_result = downImagethreading(vid, image_url, image_num,image_dir)
        for row in down_image_result:
            if row['down_result'] == False:
                comm_log.info("downImage false:" + row["error"])
                continue
        st4 = time.time()
        comm_log.info("tag 1: load imgs cost_time = "+str(st4 - st3))
	
        et_time = time.time()
        comm_log.info("tag 2: start story clip : preprocess cost_time = "+str(et_time-st_time))
        shots_info = story_clip_main2.getStoryRange(vid,video_path+"/%s.mp4"%vid,info['keyframe'],info['ocr'],info['imglist'],info['sound'],image_dir,shots_image_dir)
        et_time2 = time.time()
        comm_log.info("tag 3: end story clip : story clip cost_time = "+str(et_time2-et_time))
        save_info['cost_time'] = int(time.time()*1000)-start_time
        save_info['shots_info'] = shots_info
        with open('./logs/%s.json'%vid, 'w') as f:
            json.dump(save_info, f)
	if shots_info is None:shots_info={}
        post_result.postResult(vid,shots_info.get('sec_shots',{}))
        shot_comm.updateBaseInfoEnd(conn, vid, shot_comm.EDN_VIDEO_OK,json.dumps(shots_info))
    except Exception as e:
        comm_log.error(str(e))
        comm_log.info(traceback.format_exc())
        sys.exit()
    finally:
        if video_path is not None:
            #Tool.Tool.removeDir(video_path)
            pass
	
	#comm_log.info(image_dir)
        if image_dir is not None:
            #Tool.Tool.removeDir(image_dir)
            pass
        if shots_image_dir is not None:
            #Tool.Tool.removeDir(image_dir)
            pass



if __name__ == '__main__':
    date = time.strftime("%Y%m%d", time.localtime())
    comm_log.init(str(__file__).split(".")[0] + "_" + str(date))
    global args, config,conn
    args = getArg()
    config = ConfigParser()
    comm_log.info(str(args.config_file))
    conn = mysql_help.mysql("ocrsound_info")
    config.read(args.config_file, encoding="utf-8")
    worker()
