# coding: utf-8
import sys
import multiprocessing
import traceback
import datetime
import time
import json
sys.path.append('/usr/local/zk_agent/names')
sys.path.append("./pyscripts")
sys.path.append("./monitor_api")

import pyscripts.comm_log as comm_log
import traceback
from monitor_api.monitor_api import monitor_add, monitor_avge, monitor_set
import mysql_tool.MysqlHelper as mysql_help
import MySQLdb

EDN_VIDEO_ERRROR=101
EDN_VIDEO_OK=100


def selectinfo(conn,vid):
    table = "information_base"
    condition = "vid ='%s'"%vid
    result, error = conn.select(table, 'infostr', condition)
    if error!="":
        raise Exception(error)
    if len(result)==0:
        comm_log.error("vid %s selectinfo empty"%vid)
        return []
    return result[0]

def selectList(conn):
    table = "information_base"
    condition = "status >=3 and status<99"
    result, error = conn.select(table, 'vid,infostr,last_modify_time', condition)
    if error!="":
        raise Exception(error)
    if len(result)==0:
        comm_log.info("selectList empty")
        return []
    return result

def getlistInfo(conn,num):
    tablename = "info_base_detail"
    condition = " status=0 and type='sound' limit %d" %(num)
    result, error = conn.select(tablename, 'vid', condition)
    if error!="":
        raise Exception(error)
    return result

def getBaseDetail(conn,vid):
    tablename = "info_base_detail"
    condition = " status=1 and vid='%s'"%vid
    result, error = conn.select(tablename, 'vid,resultinfo,type', condition)
    if error!="":
        raise Exception(error)
    return result


def saveResult(conns,vid, add_result,status=-1):
	# connect mysqldb
	for _ in range(5):
		try:
			tablename = 'info_base_detail'
			tdic = {'status': status, 'resultinfo': json.dumps(add_result)}
			condition = "vid = '{}' and type = 'sound'".format(vid)
			result, error = conns.update(tablename, tdic, condition)
			return result
		except Exception as e:
			time.sleep(1)
			conns = mysql_help.mysql("ocrsound_info")
			print('EError: %s' % e)
		finally:
			pass
	return False


def updateBaseInfo(conns, vid):
	for _ in range(5):
		try:
			sql = 'update information_base set status=status+1 where vid="%s"' % vid
			result, error = conns.query(sql)
			if len(error) > 2:
				raise Exception("query false sql %s error %s" % (sql, error))
			return True
		except Exception as e:
			time.sleep(1)
			conns = mysql_help.mysql("ocrsound_info")
			print('EError: %s' % e)
			print traceback.format_exc()
		finally:
			pass
	return False

def updateBaseInfoEnd(conns,vid,status,split_info=None):
	for _ in range(5):
		try:
			if  split_info is None:
				sql = 'update information_base set status=%s where vid="%s"' % (str(status),vid)
			else:
				sql = 'update information_base set status=%s,split_info="%s" where vid="%s"' % (str(status),MySQLdb.escape_string(split_info), vid)
			result, error = conns.query(sql)
			if len(error) > 2:
				raise Exception("query false sql %s error %s" % (sql, error))
			return True
		except Exception as e:
			time.sleep(1)
			conns = mysql_help.mysql("ocrsound_info")
			print('EError: %s' % e)
			print traceback.format_exc()
		finally:
			pass
	return False
