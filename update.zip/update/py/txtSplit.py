def sortSoundTxt(sound_content,fps, vid):
	info = sound_content[vid]
	txtList,timeList = [], []
	for item in info:
		txtList.append(item["txt"])
		start_time = int(item["time_split"]["start_time"].replace('"',''))
		end_time = int(item["time_split"]["end_time"].replace('"',''))
		timeList.append([int(start_time*fps), int(end_time*fps)])
	return txtList,timeList

def merge_soundtxt(story_range_list_2, sound_content0, vid, fps,totalframes):
	txtList, timeList = sortSoundTxt(sound_content0,fps, vid)
	sound_content = sound_content0[vid]

	story_range_list = []
	last_item = None
	num=-1
	for item in story_range_list_2:
		num += 1
		if num==0:
			last_item = item
			continue
		if item[0] - last_item[1] > fps:
			startFrame = last_item[1]
			endFrame = item[0]
			ans, index_list = IntervalIntersection.outerIntersection([startFrame, endFrame], timeList)
			if len(index_list) > 2:
				data = []
				for it in sound_content:
					data.append(sound_content[it])
				index = splitTxt(data)



	return story_range_list_2
