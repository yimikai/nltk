import math
import numpy as np

class SummaryRange(object):
    def summaryRanges(self, nums):
        """
        :type nums: List[int]
        :rtype: List[str]
        """
        if not nums:
            return nums
        last = []
        res = []
        for item in nums:
            if not last:
                last.append(item)
            else:
                if item - last[-1] == 1:
                    last.append(item)
                else:
                    if len(last) == 1:
                        #res.append(str(last[0]))
                         res.append([last[0]])
                    else:
                        #res.append("%d->%d" % (last[0], last[-1]))
                         res.append([last[0], last[-1]])
                    last = [item]
        if len(last) == 1:
            #res.append(str(last[0]))
            res.append([last[0]])
        else:
            #res.append("%d->%d" % (last[0], last[-1]))
            res.append([last[0], last[-1]])
        return res

# input list like [100, 101, 102, 103, 104, 500,501, 502, 503]
# output like [[100,104],[500,503]]
def findSummaryRange(zhuchi2_range, fps):
	obj = SummaryRange()
	tlist2 = obj.summaryRanges(zhuchi2_range)
	tlist3 = []
	for item in tlist2:
		if (len(item)==2)and (item[1]-item[0])>=2:
			tlist3.append(((np.array(item)-1)*fps+math.ceil(fps/2)).tolist())
	return True, tlist3

if __name__ == '__main__':
	tlist1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126]
	a= [163, 213, 288, 313, 338, 363, 388, 413, 30638, 35663, 35688, 35713, 38913, 38938, 38963, 38988, 39013, 44238, 44263]
	obj = SummaryRange()
	tlist2 = obj.summaryRanges(tlist1)
	print(tlist2)
