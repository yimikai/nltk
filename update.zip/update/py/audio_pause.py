# -*- coding: UTF-8 -*-
import sys,traceback
import os
import time
import soundfile as sf

import numpy as np
import math

from ffmpy import FFmpeg
#import matplotlib.pyplot as plt

import cv2
import range_c

import json

VOLUMEMAX = 32768 * 32768
kMinLevel = 1



class CheckAudio(object):
	def __init__(self, video_path, fps):
		#self.video_path = video_path
		self.fps = fps

	    	audio_path = 'temp.wav'
	    	os.system('rm temp.wav')
	
	    	ff = FFmpeg(
	    	    inputs={video_path: None},
	    	    outputs={audio_path: '-acodec pcm_s16le -ac 1 -ar 16000'}
	    	)
	    	ff.cmd
	    	ff.run()
	
	    	video = cv2.VideoCapture(video_path)
	
	    	if not video.isOpened():
	    	    print("video open error ")
	    	    print(video_path)
	    	    return -1, -1

	    	try:
	    	    wav_data, sr = sf.read(audio_path, dtype='int16')
	    	except Exception as e:
	    	    traceback.print_exc()
	    	    return -1, -1
	    	assert wav_data.dtype == np.int16, 'Bad sample type: %r' % wav_data.dtype
	
	    	self.samples = wav_data
		self.sr = sr
	    	#sf.write('new.wav',wav_data[start_num:end_num], sr)

	def find_max_silence(self, start_num, end_num, pitch_threshold=900):
	    	start_num = int((float(start_num) / self.fps) * self.sr)
	    	end_num = int((float(end_num) / self.fps) * self.sr)
	    	print("audio st and end :"+str(start_num)+" "+str(end_num))

	    	pitch_list = []
	    	for j in range(start_num, end_num, 1):
	    	    if abs(self.samples[j]) < pitch_threshold:
	    	        pitch_list.append(0)
	    	        #pitch_list.append(abs(self.samples[j]))
	    	    else:
	    	        pitch_list.append(1)
	    	        #pitch_list.append(abs(self.samples[j]))
	
	    	longest_t, pos = range_c.find_length(pitch_list, 0)
	    	#print(pitch_list)
	    	return int(float(longest_t)*self.fps/self.sr), int(float(pos+start_num)*self.fps/self.sr)

def save_json(vid, data):
    file_name = vid + '_stops' + '.json'

    with open(file_name, 'w') as save_f:
        data1 = {'stops': data}
        data2 = {vid: data1}

        json.dump(data2, save_f, ensure_ascii=False)


def sound_pause_audio_detect(audiopath1, shots_list, fps_num,threshold, yin_height, plot=False):
    #yin_height = 1000
    try:
        wav_data, sr = sf.read(audiopath1, dtype='int16')
    except Exception as e:
        traceback.print_exc()
        return -1
    assert wav_data.dtype == np.int16, 'Bad sample type: %r' % wav_data.dtype
    # samples = wav_data / 32768.0  # Convert to [-1.0, +1.0]
    samples = wav_data
    result = 0
    wav_length = len(samples)
    downsamples = []

    for i in range(0, wav_length, sr/10):
        downsamples.append(samples[i])

    shots_num = len(shots_list)
    if shots_num < 2:
        print ("shots num < 2")
        return []

    pause_list = []
    pause_list_detail = []

    for i in range(shots_num -1):
        pause_result = 0
        start_num = int((float(shots_list[i][1]) / fps_num) * sr)
        end_num = int((float(shots_list[i + 1][0]) / fps_num) * sr)

        silent_num = 0
        sample_num = 0.000000001

        for j in range(start_num, end_num, 1):
            sample_num += 1
            if abs(samples[j]) < yin_height:
                silent_num += 1

        slient_duty = silent_num / float(sample_num)

        #if slient_duty > 0.999:
        if slient_duty > threshold:
            pause_result = 1
        else:
            pause_result = 0

        if (pause_result ==1):

            pause_result = 0

            mid_num = int((float(shots_list[i][1] + shots_list[i + 1][0]) / (2 * fps_num)) * sr)

            for k in range(8):
                start_num = max(0, mid_num - 6 * sr / 10 + k * sr / 10)
                end_num = min(wav_length, start_num + sr / 3)
                silent_num = 0
                sample_num = 0

                for j in range(start_num, end_num, 1):
                    sample_num += 1
                    if abs(samples[j]) < yin_height:
                        silent_num += 1

                slient_duty = silent_num / float(sample_num)

                #if slient_duty > 0.999:
                if slient_duty > threshold:
                    pause_result = 1

        pause_list_detail.append([pause_result,shots_list[i][1],shots_list[i+1][0]])
        pause_list.append(pause_result)

    #print pause_list_detail
    return pause_list


def sound_pause_video_detect(video_path1,shots_list, vid, threshold, yin_height):
    #妫€娴嬫棤澹拌棰�
    audio_path = 'temp.wav'
    os.system('rm temp.wav')

    ff = FFmpeg(
        inputs={video_path1: None},
        outputs={audio_path: '-acodec pcm_s16le -ac 1 -ar 16000'}
    )
    ff.cmd
    ff.run()

    video = cv2.VideoCapture(video_path1)

    if not video.isOpened():
        print("video open error ")
        print(video_path1)
        return -1

    fps_num = int(video.get(cv2.CAP_PROP_FPS))
    print ('fps_num is', fps_num)


    result_audio = sound_pause_audio_detect(audio_path,shots_list,fps_num, threshold, yin_height)

    #vid = video_path1.split("/")[-1].split(".")[0]

    #print (vid ,result_audio)
    save_json(vid, result_audio)


    return result_audio


def load_json(file_path,vid):
    with open(file_path, 'r') as load_f:
        load_dict = json.load(load_f)
        #print(load_dict)
    #load_dict['smallberg'] = [8200, {1: [['Python', 81], ['shirt', 300]]}]

    #vid = file_path.split("/")[-1].split("_")[0]
    shots_list = load_dict[vid]['shots']
    return shots_list


if __name__ == '__main__' :
    audiopath1 = sys.argv[1]
    leng, pos = find_silence(audiopath1, 15, 900, 8468-45, 8798+45)
    print(leng)
    print(pos)


#    video_path1 = sys.argv[1]
#    json_path1 = sys.argv[2]
#    time_start = time.time()
#    vid = video_path1.split("/")[-1]
#
#
#    shots_list = load_json(json_path1, vid)
#
#    try:
#
#        if '.mp4' in video_path1:
#            result = sound_pause_video_detect(video_path1, shots_list, vid)
#            time_record1 = time.time() - time_start
#            print ('time_record1', time_record1)
#
#
#
#    except Exception as e:
#        traceback.print_exc()
        

