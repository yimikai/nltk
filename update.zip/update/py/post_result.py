import requests
import json
import l5router.l5router as l5router
import pyscripts.comm_log as comm_log
import math

def postResult(vid,txt):
	for _ in range(5):
		try:
			l5_address_info = "65:1409024".split(":")
			comm_log.info(l5_address_info)
			server_port = l5router.l5_ns_router(int(l5_address_info[0]), int(l5_address_info[1]))
			print(server_port)
			url = "http://%s/api/SkyHighLight/finished"%(server_port)
			#params = urllib.parse.urlencode({"vid":vid,'fragments':json.dumps(txt)})
			#print(params)
			params = {"vid":vid,'fragments':json.dumps(txt)}
			#url += params
			comm_log.info("vid:" + str(vid) + " post txt url:"+url)
			req = requests.post(url,data=params,headers={'HOST':'nt.video.cloud.cctv.com'})
			response = req.content.decode("utf-8")
			comm_log.info("vid:" + str(vid) + " post txt response:" + str(response))
			response  = json.loads(response)
			print("=====================================")
			print(response['response']['code'])
			if int(response['response']['code'])==0:
				return True
			else:
				raise Exception(" response error %s"%str(req.content.decode("utf-8")))
		except Exception as e:
			comm_log.error("%s has error %s"%(vid,str(e)))
			print("%s has error %s"%(vid,str(e)))
	return
