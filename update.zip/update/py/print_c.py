import numpy as np

# print list which is frame-list, print its second-list
def print_list_sec(list_a, fps):
	for item in list_a:
		print(np.array(item)/fps)

# print origin list
def print_list(list_a):
	for item in list_a:
		print(item)
#print txt list, show its txt content and range 
def print_dict(s):
	print('----print----')
	last_txt=''
	for i in range(len(s)):
	    if s[i][1][0]!=s[i][1][1]:
	
	        txt = s[i][0]
	        txt = "".join(txt.split())
	
	        tmp={}
	        tmp["txt"]=txt
	
	        minp = s[i][1][0]
	        maxp = s[i][1][1]
	        print(txt +" ["+str(minp)+","+str(maxp)+"]")
	return

