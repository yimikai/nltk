
from tool import * 
from mergeRange import *
from SummaryRange import *
import math
import check 
import overlap
def postprocess_txt(tmp_txt, fps, totalframes):
	s=sorted(tmp_txt.items(),key=lambda x:x[1][0])
	out, tmp_txt = sort_merge(s)
	s=sorted(tmp_txt.items(),key=lambda x:x[1][0])
	out, tmp_txt = fuzzy_matching(s)
	s=sorted(tmp_txt.items(),key=lambda x:x[1][0])
	print_dict(s, fps)

	print("before merge : out")
	print(out)
	obj = MergeRange()
	out = obj.merge(out)
	print("after merge : out")
	print(out)
	out = check.checkError(out, totalframes, fps)
	#out = overlap.dilate(out, int(fps/3))

	return out
#print dict
def print_dict(s, fps):
	print('----print----')
	last_txt=''
	for i in range(len(s)):
	    if s[i][1][0]!=s[i][1][1]:
	
	        txt = s[i][0]
	        txt = "".join(txt.split())
	
	        tmp={}
	        tmp["txt"]=txt
	
	        #minp = s[i][1][0]
	        #maxp = s[i][1][1]
	        minp = int(s[i][1][0]-math.ceil(fps/2))/fps+1
	        maxp = int(s[i][1][1]-math.ceil(fps/2))/fps+1
	        print(txt +" ["+str(minp)+","+str(maxp)+"]")
	return
