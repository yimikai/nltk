# -*- coding: utf-8 -*-
import os,sys
from PIL import Image
import json
import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
reload(sys) 
sys.setdefaultencoding('utf8')
#sys.path.append("./pyscripts/")

from PIL  import Image #, ImageDraw
from getcolor import *
import re
import string
from mergeRange import *
from Classify import *
import subprocess
#from  make_soundstop import *
from SummaryRange import *
import copy
import math
from tool import * 
import traceback
import postprocess_txt as postp_txt
import check

# find shots including all tv imgs
def tvdict2list(tvdict):
	if not tvdict:
		return []

	tvlist = []

	tvdict2 = sorted(tvdict.items(),key=lambda x:x[0])
	for item in tvdict2:
		#print(item)
		if len(item[1]["start"])==3 and len(item[1]["end"])==3 and (item[1]["end"][-1]-item[1]["start"][0]>40):
			tvlist.append([item[1]["start"][0],item[1]["end"][-1]])

	print("tvlist patch: ")
	print(tvlist)
	return tvlist

def loadtext(txt_dict ,vid, zhuchiren_content, shotsimgfolder, fps, totalframes, bbox):
	zhuchi2_range = []
	try:
		out_txt={}
		out_range={}
		tmp_txt={}
		#txt_dict = json.load(open(txtpath,'r'))
		txtstop_list = []
		subtxt_range = []
		min_subtxt =1000000
		max_subtxt = 0
		last_subtxt = ""
		lastpatch=[]
		count=-1
		tvdict = {} # "shot1":{"start":[],"end":{}}
		last_shot = 0
		
		for content in sorted(txt_dict,key=lambda content:int(content["path"].split("_")[0]),reverse=False):
			#print("---for 1 img-----"+content["path"])
			#imgpath = "xinwen2/A_out_data_storys/shots_"+vid+"/"+content["path"]
			imgpath = shotsimgfolder+"/"+content["path"]
			print(imgpath)
			if os.path.exists(imgpath)==False:
				print(imgpath+" not exist.")
				continue
			img = Image.open(imgpath)
			img, w, h, scale_w, scale_h = check.checkImgScale(img)
			
			shot_num = float(content["path"].split("_")[-1].split(".jpg")[0][4:])
			index = int(content["path"].split("_")[0])
			second = int(index - math.ceil(fps/2))/fps+1 

			tmp=str(shot_num-0.5)
			current_shot = int(math.floor(shot_num-0.5))
			if current_shot==0:
				tvdict[current_shot]={"start":[], "end":[]}
			if current_shot!=last_shot:
				tvdict[current_shot]={"start":[], "end":[]}
				last_shot = current_shot 

			index_num = int(content["path"].split("_")[0])
			# recog head of shot
			flag0, value = television( content["path"],vid, "shots", zhuchiren_content)
			cmd = ""
			if flag0==True:
				cmd = "cp "+ imgpath +" tv/"
				if (tmp.split(".")[-1]=="0"):# and (shot_num!=last_shot): # cpmpare with befpre_shot
					tvdict[current_shot]["start"].append(index_num)  
				else:
					tvdict[current_shot]["end"].append(index_num)  
			else: #if flag0==True:
				cmd = "cp "+ imgpath +" notv/"
			flag11 = run_shell(cmd)
			
			text_dict = content["txt"]
			
			content_txt=''
			tag_content = "-1"
			for key in text_dict.keys(): #key is order index, meaning how many text-lines 
			    line_text_dict = text_dict[key]
			    line_box_i = line_text_dict['line_box']
			
			    #flag, tag, height, width = subtxt(line_box_i, img, scale_w, scale_h, index_num)
			    flag, tag, height, width = subtxt0(line_box_i, img, scale_w, scale_h, index_num, w, h,  bbox)
			    if flag!="":
			        content_txt = line_text_dict['txt'].strip()
			        content_txt = "".join(content_txt.split())
			        content_txt = ''.join(re.findall(u'[\u4e00-\u9fff]+', content_txt))

			    	if flag=="2zhuchi":
			    	    zhuchi2_range = save2zhuchi(zhuchi2_range, second, content_txt)
			            continue
			
			        tag_content=tag
			        print("height = "+str(height) +" color = "+str(tag)+" content="+str(content_txt))
			        count+=1
			
			        if content_txt=="":
			            continue
			
			        #if (count==0) and (tag=="blue") and (25< height<38):
			        if (count==0) and (tag=="blue") and (14< height<38 or (30< height<80 and (w==1920 or w==864))):
			            last_subtxt = content_txt
			            continue
			
			        #if (tag=="blue") and (24< height<40): # record subtxt 
			        if (tag=="blue") and  ((14< height<38) or (30< height<80 and (w==1920 or w==864))): # record subtxt 
			            min_subtxt,max_subtxt, last_subtxt, subtxt_range, tmp_txt = find_range(content["path"], min_subtxt, max_subtxt, last_subtxt, content_txt, subtxt_range, tmp_txt, index)
			out_txt[content['path']]={"txt":content_txt,"tag":tag_content}
		
		# save last subtext
		if min_subtxt < max_subtxt:
			tmp_txt[last_subtxt]=[min_subtxt, max_subtxt]
			subtxt_range.append([min_subtxt, max_subtxt])

		if len(subtxt_range)==0:
			return [], tvdict2list(tvdict),out_txt

		# sort result
		out = postp_txt.postprocess_txt(tmp_txt, fps, totalframes)
		out_range['range']=out
		
		return out, tvdict2list(tvdict), zhuchi2_range, out_txt
		
	except Exception as e:
		print(str(e))
		print(traceback.format_exc())
	
	return [], [], [], []
