
	def process_tv_txt(self, tvlist4, txt_range):
		#1
		txt_range2 = txt_range + tvlist4
		obj = MergeRange()
		txt_range3 = obj.merge(txt_range2)
		print("merge txt_range and tvlist4: ")
		print(txt_range3)

		#2
		last_item = txt_range3[0]
		count = -1 
		txt_range4 = []
		for item in txt_range3:
			count += 1
			if count == 0:
				txt_range4.append(item)
				continue 
			if (last_item[1]-last_item[0] == 2) and (item[1] -item[0]>2): # zhuchiren and txtrange
				txt_range4[-1][1]=item[1]
				last_item = txt_range4[-1] 
				continue
			
			if (last_item[1]-last_item[0] > 2) and (item[1] -item[0]==2): # txtrange and zhuchiren
				maxtmp = last_item[1]
				if item[0]-3 > last_item[1]:
					maxtmp = item[0]-3
				txt_range4[-1][1] = maxtmp
				txt_range4.append(item)
				last_item = item 
				continue
			
			txt_range4.append(item)
			last_item = item 
		print("after combine zhuchiren and  txt_range")
		print(txt_range4)

		#3: delete zhuchiren shots range, only record txtrange
		print("after delete tv shots range, only record txtrange")
		txt_range5 = []
		for item in txt_range4:
			if item[1]-item[0] != 2: # not tv image
				txt_range5.append(item)
		print(txt_range5)

		print("04: tvlist4:")
		print(tvlist4)

		return txt_range5 
