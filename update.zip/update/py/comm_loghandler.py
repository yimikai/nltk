#!/usr/bin/env python
#coding=utf8
import time
import logging

class MyHandler(logging.handlers.TimedRotatingFileHandler):
    """
    自己定义的TimedRotatingFileHandler
    """
    def __init__(self, log_file, when, interval, backupCount):
        self.when = when 
        self.interval = interval
        self.backupCount = backupCount
        self.dayOfWeek = 0
        logging.handlers.TimedRotatingFileHandler.__init__(self,
                log_file,
                when=self.when, interval=self.interval,
                backupCount=self.backupCount, encoding="utf-8")
        t = int(time.time())
        self.rolloverAt = self.computeRollover(t)

    def computeRollover(self, currentTime):
        """
        Work out the rollover time based on the specified time.
        """
        s = time.localtime(currentTime)
        newtime = currentTime        
        if self.when == 'M':
            newtime = time.mktime((s.tm_year,s.tm_mon,s.tm_mday,s.tm_hour,s.tm_min,0,s.tm_wday,s.tm_yday,s.tm_isdst))
        if self.when == 'H':
            newtime = time.mktime((s.tm_year,s.tm_mon,s.tm_mday,s.tm_hour,0,s.tm_sec,s.tm_wday,s.tm_yday,s.tm_isdst))
        if self.when == 'D':
            newtime = time.mktime((s.tm_year,s.tm_mon,s.tm_mday,0,0,s.tm_sec,s.tm_wday,s.tm_yday,s.tm_isdst))
        result = int(newtime) + self.interval
        #result = currentTime + self.interval
        if self.when == 'MIDNIGHT' or self.when.startswith('W'):
            # This could be done with less code, but I wanted it to be clear
            t = time.localtime(currentTime)
            currentHour = t[3]
            currentMinute = t[4]
            currentSecond = t[5]
            # r is the number of seconds left between now and midnight
            r = _MIDNIGHT - ((currentHour * 60 + currentMinute) * 60 +
                    currentSecond)
            result = currentTime + r
            # If we are rolling over on a certain day, add in the number of days until
            # the next rollover, but offset by 1 since we just calculated the time
            # until the next day starts.  There are three cases:
            # Case 1) The day to rollover is today; in this case, do nothing
            # Case 2) The day to rollover is further in the interval (i.e., today is
            #         day 2 (Wednesday) and rollover is on day 6 (Sunday).  Days to
            #         next rollover is simply 6 - 2 - 1, or 3.
            # Case 3) The day to rollover is behind us in the interval (i.e., today
            #         is day 5 (Saturday) and rollover is on day 3 (Thursday).
            #         Days to rollover is 6 - 5 + 3, or 4.  In this case, it's the
            #         number of days left in the current week (1) plus the number
            #         of days in the next week until the rollover day (3).
            # The calculations described in 2) and 3) above need to have a day added.
            # This is because the above time calculation takes us to midnight on this
            # day, i.e. the start of the next day.
            if self.when.startswith('W'):
                day = t[6] # 0 is Monday
                if day != self.dayOfWeek:
                    if day < self.dayOfWeek:
                        daysToWait = self.dayOfWeek - day
                    else:
                        daysToWait = 6 - day + self.dayOfWeek + 1
                    newRolloverAt = result + (daysToWait * (60 * 60 * 24))
                    dstNow = t[-1]
                    dstAtRollover = time.localtime(newRolloverAt)[-1]
                    if dstNow != dstAtRollover:
                        if not dstNow:  # DST kicks in before next rollover, so we need to deduct an hour
                            newRolloverAt = newRolloverAt - 3600
                        else:           # DST bows out before next rollover, so we need to add an hour
                            newRolloverAt = newRolloverAt + 3600
                    result = newRolloverAt
        return result


