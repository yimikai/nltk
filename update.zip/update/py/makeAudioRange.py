# -*- coding: UTF-8 -*-
import sys,traceback
import os
import time
#import soundfile as sf
import numpy as np
import math
from ffmpy import FFmpeg
#import matplotlib.pyplot as plt
import cv2
import json
from pyscripts import audio_pause
from audio_pause import *


def audioRange(audiostop_list, shots_list, fps):
	fps= int(fps)
	shots_num = len(shots_list)
	audiorange = []
	last_s  = 0
	last_end = -1 #shots_list[0][1]
	print("length audioshots="+str(len(shots_list)))
	print("length audiostops="+str(len(audiostop_list)))
	#print("audiostops="+str(audiostop_list))

	for i in range(shots_num-1):
		if audiostop_list[i]==1:
			last_end = shots_list[i][1]
			#audiorange.append([last_s,last_end])
			# indent 1s 
			if last_end - int(fps*0.1) > last_s + int(fps*0.1):
				audiorange.append([last_s+int(fps*0.1),last_end-int(fps*0.1)])
			last_s = shots_list[i+1][0]
	return audiorange
			


def makeAudioRange(video_path, shot_content, vid, fps, threshold, yin_height): 
	result = sound_pause_video_detect(video_path, shot_content["shots"], vid, threshold, yin_height)
	audiorange = audioRange(result, shot_content["shots"], fps)

	return audiorange


if __name__ == '__main__' :
    video_path1 = sys.argv[1]
    json_path1 = sys.argv[2]
    time_start = time.time()
    vid = video_path1.split("/")[-1]


    shots_list = load_json(json_path1, vid)

    try:

        if '.mp4' in video_path1:
            result = sound_pause_video_detect(video_path1, shots_list, vid)
            time_record1 = time.time() - time_start
            print ('time_record1', time_record1)

            audiorange = audioRange(result, shots_list)
            print(audiorange)

    except Exception as e:
        traceback.print_exc()

