import sys,os
import json
class Classify(object):
	def __init__(self, key, vid, label, zhuchiren_content):
			self.key = key
			self.vid = vid
			self.label = label
			self.content = zhuchiren_content
	    
	def classify(self):
		vid = self.vid
		key = self.key
		label = self.label
		content = self.content
		#print("tv content= ")
		#print(content)
		# label="shots" or "1s"
		if self.label == "shots":
			print("shot img not recog zhuchireni Now.")
			return ""
		#path="/data/home/alinahu/xinwen/story/xinwen2/result_large_zhuchiren_shots"
		#json_path=path+"/output_result_shots_"+vid+".json"
		#content = json.load(open(json_path,'r'))
		# get recog result 
		#key = "20725_0_shot238.0.jpg"
		if key in content.keys():
			
			value = content[key]["scene"]
			if content[key]["prob"] >0.9 and ((value=="xinwenhuamian") or (value=="zhuchiren")):
				return value
		else:
			print("zhuchiren Key: Keyfail: No key = "+str(key))
		return ""
