import sys,os
import  cv2
import numpy as np
import colorList
from PIL import Image
 
#filename=sys.argv[1]#'xinwen2/A_out_data_storys/crop/1817_0_shot3.0_crop.jpg'

#input frame must be Pil format ! Not cv pilimage format!
def get_color(frame, width):
    #print('go in get_color')
    print(type(np.asarray(frame)))
    #r, g, b, a = frame.split()
    #frame = Image.merge("RGB", (r, g, b))
    #print(frame.ndim)
    frame2 = cv2.cvtColor(np.asarray(frame),cv2.COLOR_RGB2BGR) 
    #size = frame2.shape 
    hsv = cv2.cvtColor(frame2,cv2.COLOR_BGR2HSV)
    maxsum = -100
    color = None
    color_dict = colorList.getColorList()
    for d in color_dict:
        #print("color_dict= 0: "+str(color_dict[d][0])+" 1:"+str(color_dict[d][1]))
        #print(d)
        mask = cv2.inRange(hsv,color_dict[d][0],color_dict[d][1])
        #cv2.imwrite(d+'.jpg',mask)
        binary = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)[1]
        binary = cv2.dilate(binary,None,iterations=2)
        img, cnts, hiera = cv2.findContours(binary.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        sum = 0
        for c in cnts:
            sum+=cv2.contourArea(c)
        #print(str(d)+" sum="+str(sum))
        if sum > maxsum :
            maxsum = sum
            color = d

    if color=='blue':
        print(color+" sum="+str(maxsum))
    if width==1920 and maxsum >3000:#3500
        return color
    elif width==360 and maxsum >130:#400
        return color
    else:
        return None
 
 
if __name__ == '__main__':
    #frame = cv2.imread(filename)
    #print(get_color(frame))

    #frame = cv2.imread(sys.argv[1])
    color="-1"
    frame = Image.open(sys.argv[1])
    color =  get_color(frame)
    print(color)
    if color!=None:
        print(color)


#    dir = sys.argv[1]
#    for root,dirs,files in os.walk(dir):
#        print('----------------')
#        for file in files:#,key=lambda file:int(file.split("_")[0]),reverse=False):
#            pth = os.path.join(root,file)
#            print(pth)
#            frame = cv2.imread(pth)
#            print(get_color(frame))
