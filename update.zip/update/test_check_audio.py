import sys, os
import pyscripts.audio_pause as audio_pause
from story_clip_main2 import *

# clip audio range again



st_list = [[0, 2143], [3349, 4895], [4898, 5700], [5703, 8468], [8798, 9298], [10282, 11156], [11159, 11937], [11940, 12818], [12821, 17026], [17029, 18024], [18027, 19324], [19327, 19548], [19551, 19753], [19756, 20800], [20803, 22288], [22291, 22989], [23616, 23831], [23896, 24212], [24215, 24521], [24524, 25216], [25220, 25428], [25666, 25959], [25964, 26668], [26671, 26785]]
video_path = sys.argv[1]
fps = 15
out_list = check_audio(st_list, video_path, fps)
print('------')
print(st_list)
print(out_list)
