#--coding utf-8--
import os,sys
import json


if __name__ == '__main__':
	'''
	zhuchiren_json_path = sys.argv[1]
	zhu_dict = json.load(open(zhuchiren_json_path,'r'))
	zhu_d = sorted(zhu_dict.keys(), reverse=False) # ,key=lambda x:x[1][0])
	print(zhu_d)
	for content in zhu_d: #,key=lambda content:int(content["order"]),reverse=False):
		print(str(content)+"  "+str(zhu_dict[content]))
	
	'''
		
	zhuchiren_path = sys.argv[1]
	cc = open(zhuchiren_path, 'r')
	aa=[]
	for line in cc:
		con = line.strip().split(" ")
		for item in con:
			if item.find(".jpg")!=-1:
				#aa.append(int(item.split(".jpg")[0]))
				aa.append(int(item.split(".jpg")[0].split("'")[-1]))
	print(sorted(aa))
