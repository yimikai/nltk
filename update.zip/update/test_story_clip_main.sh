vid=$1
/usr/local/qqwebsrv/python-2.7.8/bin/python story_clip_main2.py $vid
