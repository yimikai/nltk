#--coding utf-8--
import os,sys
from PIL import Image
import json
import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
reload(sys) 
sys.setdefaultencoding('utf8')

from PIL  import Image, ImageDraw
from getcolor import *
from pydub import AudioSegment
import re
from searchInsert import *
from IntervalIntersection import *
from mergeRange import *
import copy
import numpy as np
import overlap

class processsound():
	def __init__(self, vid, txtrange, tvrangelist, leftrange, soundcontent, shot_content, fps=15):
			self.vid = vid
			if not txtrange:
				self.txtrange = []
			else:
				self.txtrange = np.concatenate(txtrange).tolist()
			if not tvrangelist:
				self.tvrangelist = []
			else:
				self.tvrangelist = np.concatenate(tvrangelist).tolist()
			self.leftrange = leftrange
			self.soundcontent = soundcontent #json.load(open(soundpath,'r'))
			self.fps = fps
			self.shot_content = shot_content
	
	def loadshotsdict2list(self, shots_dict, vid):
		#shots_dict = json.load(open(path,'r'))
		clip_list=shots_dict["shots"]
		#clips = np.concatenate(clip_list).tolist()
		#print(clips)
		return clip_list


	def splitsoundbytxtrange(self, pos_s, pos_e):
		flag = False
		gap = abs(pos_e-pos_s)
		# overlap different subtext, so this patch should be deletedt
		if gap>=3:
		    flag = True
		    num = int(gap/2)-1
		    return flag, num
		#if gap==3 and pos_s%2!=0:
		if gap==2 and pos_s%2!=0 and pos_e%2==0:
		    flag = True
		    num = int(gap/2)
		    return flag, num
		return flag, 0
	
	def splitsoundbytvrange(self, pos_s, pos_e, nums, start, end):
		flag = True
		gap = abs(pos_e-pos_s)
		num_str = str(nums)
		# overlap different subtext, so this patch should be deletedt
		if (gap==0) and (pos_s%2==0) and (num_str.find(str(start))!=-1 and num_str.find(str(end))!=-1): # canot be same as one tv image
		    flag = False
		    num = int(gap/2)-1
		    return flag, num
		return flag, 0



	
	def findrangeOverlap(self, start, end,vid):
		#txtrangepath = self.txtrangepath #"json/"+vid+"_subtxt_range_1s.json" #sys.argv[2]
		nums = self.txtrange
		print("txt range:")
		print(nums)
		ob = Search(nums)
		print("find sound: start="+str(start)+" end="+str(end))
		pos_s = ob.searchInsert(start)
		#pos_s = searchInsert(nums, start)
		pos_e = ob.searchInsert(end)
		# whether including more than 1 txtrange, and get how many clip_postion 
		flag, num = self.splitsoundbytxtrange(pos_s, pos_e) 
		print("insert pos: pos_s="+str(pos_s)+" pos_e="+str(pos_e))
		if flag == True:
			return flag, num
	
		# find overlap with tvrange
		nums = self.tvrangelist
		print("tvrangelist range:")
		print(nums)
		ob = Search(nums)
		print("find sound: start="+str(start)+" end="+str(end))
		pos_s = ob.searchInsert(start)
		#pos_s = searchInsert(nums, start)
		pos_e = ob.searchInsert(end)
		# whether including more than 1 txtrange, and get how many clip_postion 
		flag, num = self.splitsoundbytvrange(pos_s, pos_e, nums, start, end) 
		print("insert pos: pos_s="+str(pos_s)+" pos_e="+str(pos_e))
		return flag, num
	

	def findrangeOverlap2(self, start, end,vid):
		nums = self.leftrange
		print("txt range:")
		print(nums)
		ob = Search(nums)
		print("find sound: start="+str(start)+" end="+str(end))
		pos_s = ob.searchInsert(start)
		#pos_s = searchInsert(nums, start)
		pos_e = ob.searchInsert(end)
		# whether including more than 1 txtrange, and get how many clip_postion 
		flag, num = self.splitsoundbytvrange(pos_s, pos_e, nums, start, end)
		print("insert pos: pos_s="+str(pos_s)+" pos_e="+str(pos_e))
		if flag == True:
			return flag, num
		return flag, num
	

	def findintersection(self, soundrange, leftrange):
		obj = IntervalIntersection()
		section = obj.intervalIntersection(leftrange,soundrange)
		return section


	#delete overall overlap range, and return left range
	def deleteoveralllap(self, patch, trange, totalframes):
		if trange==[[0,totalframes]]:
			return patch

		leftrange = []
		for item in patch:
			flag, _ = overlap.overalllap(item, trange)
			if flag==False:
				leftrange.append(item)
		return leftrange


	def loadsoundtext2(self, totalframes):
		vid = self.vid 
		fps = self.fps
		txt_dict = self.soundcontent #json.load(open(soundpath,'r'))
		
		soundpatch = {}
		patch=[]
		for content in sorted(txt_dict,key=lambda content:int(content["order"]),reverse=False):
		    index = content["order"]
		    text_dict = content["txt"]
		    text_dict = "".join(text_dict).encode('utf-8').strip()
		    print("sound dict:")
		    print(text_dict)
		
		    start_time = int(content["time_split"]["start_time"].replace('"',''))
		    end_time = int(content["time_split"]["end_time"].replace('"',''))
		
		    start = int(start_time*fps/1000)
		    end = int(end_time*fps/1000)
		    print("sound dict: start="+str(start)+" end="+str(end))
		    patch.append([start+fps,end-fps])
		
		soundpatch["soundrange"]=patch
		print(" sound range: ")
		print(patch)
		print("2: left range: ")
		print(self.leftrange)
		left_range_notoverlap = self.deleteoveralllap(patch, self.leftrange, totalframes)
		print("3: left notoverlap range: ")
		print(left_range_notoverlap)

		# load shots range
		shots_range = self.loadshotsdict2list(self.shot_content, vid)
		left_shotsrange_notoverlap = self.deleteoveralllap(shots_range, self.leftrange, totalframes)


		intersection_sound_leftrange = []
		intersection_shots_leftrange = []
		# merge sound_leftrange and shots_leftrange
		range_last = []
		for item in self.leftrange:
			# intersection of sounds and every left range item 
			intersection_range = self.findintersection(left_range_notoverlap, [item])
			# intersection of shots and every left range item 
			intersection_range2 = self.findintersection(left_shotsrange_notoverlap, [item])

			intersection_range2_cp = copy.deepcopy(intersection_range2)
			intersection_range_cp = copy.deepcopy(intersection_range)
			intersection_sound_leftrange.append(intersection_range_cp)
			intersection_shots_leftrange.append(intersection_range2_cp)

			# merge sound+leftrange and shots+leftrange
			intersection_range4 = intersection_range2+ intersection_range
			obj = MergeRange()
			range5 = obj.merge(intersection_range4)
			range_last.append(range5)

		#json.dump(soundpatch, open("json0730/"+vid+"_soundpatch_1s.json",'w'))
		return intersection_sound_leftrange, intersection_shots_leftrange, range_last



if __name__ == '__main__':
	#txtpath = sys.argv[1]
	global vid
	vid = sys.argv[1]
	tvrange_list = sys.argv[2]
	#txtrangepath = sys.argv[2] # b0875alm66w_subtxt_range_1s.json
	obj = processsound(vid, tvrange_list)
	patch = obj.loadsoundtext()
