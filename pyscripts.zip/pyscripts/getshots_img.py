
# -*- coding: utf-8 -*-
import sys
#import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
import os
# os.environ['CUDA_VISIBLE_DEVICES']='0'
#import ocr
import time
import shutil
import numpy as np
from PIL import Image
from glob import glob
import cv2
import os

import json
import shutil
import cv2
from  datetime  import  *
import time
import traceback
from PIL import Image
sys.path.append("./pyscripts")
#import comm_log
import numpy as np
import math

def saveimg(im,savepath):#img is cv2 format
    #print(savepath)
    cv2.imwrite(savepath,im)
    return 0,0

def getimg(shots_dict, video_path,frames_folder):
    try:
	print("=== get shots img ==== "+video_path)
        cap = cv2.VideoCapture(video_path)

        total_frames_num = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        print("total num=%d"%total_frames_num)

        fps=int(cap.get(cv2.CAP_PROP_FPS))
        print("-fps = "+str(fps))

        clip_list=[]
        clip_list=shots_dict["shots"]

        clip_list2=[]
        last_end = clip_list[0][1]
        for i in range(len(clip_list)):
            shot=clip_list[i]
            if shot[0]==shot[1]:#delete same start and end shot!!!!!!!!!
               print("error: same start and end shot!")#continue
               continue
            if shot[0]>shot[1]:
               #exit()
               print("error, start>end")
            if (i!=0) and (shot[0]<=last_end):
               #exit()
               print("error, start>end")
	       continue
            clip_list2.append(shot)
            last_end=shot[1]

	clip_np = []
	if len(clip_list2)>0:
        	clip_np = np.concatenate(clip_list2).tolist()

        num=-1
        sucess=True
        shot_num = 0
        frames=[]
        label=0
        samestory_pos=[] # subtext same or not in shot boundary, recording postion in video
        num_gap=-1

        flag=True
        seg_start = 0
        seg_end = -1
        strnd_count_story = 0
        count_story = 0
        while sucess:
            num+=1
            sucess,im = cap.read() # get next frame
            frames.append(im)
            #print("getshots:"+str(num))

            # find in shots boundary 
            if num in clip_np:
                shot_num+=1
                if num<2:
                    continue
                if  shot_num%2==0:
                    # save shots imgs before shots interval 
                    savepath=frames_folder+str(num)+"_0_shot"+str(float(shot_num)/2)+".jpg"
                    res, segments = saveimg(frames[-1], savepath)
                    savepath=frames_folder+str(num-1)+"_0_shot"+str(float(shot_num)/2)+".jpg"
                    res, segments = saveimg(frames[-2], savepath)
                    savepath=frames_folder+str(num-2)+"_0_shot"+str(float(shot_num)/2)+".jpg"
                    res, segments = saveimg(frames[-3], savepath)
                    label=0
                    flag=True
                    frames = []
                else:
                    num_gap+=1
                    savepath=frames_folder+str(num)+"_1_shot"+str(float(shot_num)/2)+".jpg"
                    label +=1 
                    res, after_segments = saveimg(im,savepath)
                    flag=False
                continue

            # save shots imgs after shots interval 
            if label<3 and flag==False:
                savepath=frames_folder+str(num)+"_1_shot"+str(float(shot_num)/2)+".jpg"
                label +=1 
                res, after_segments = saveimg(im,savepath)
        cap.release()
        print("-youxiao frames = "+str(num))

    except Exception as e:
        print(traceback.format_exc())
        print(e)

    return num+1, fps

def getshots_img(video_path, shots_content, vid,frames_folder):
    #global frames_folder
    #frames_folder = "./data_storys/shots_"+vid
    if os.path.exists(frames_folder)==False:
        os.makedirs(frames_folder)
    else:
        shutil.rmtree(frames_folder)
        os.makedirs(frames_folder)
    if os.path.exists(video_path):
        totalframes, fps = getimg(shots_content,video_path,frames_folder)
    return frames_folder, totalframes, fps

if __name__ == '__main__':
    video_path = sys.argv[1]
    frames_folder = getshots_img(video_path, shots_content, vid)
