
from PIL  import Image
import overlap

def checkImgScale(img):
	#img = Image.open(imgpath)
	w,h = img.size
	w, h = float(w), float(h)
	scale_w = -1 #w/360.0
	scale_h = -1 #h/270.0 

	# crop not-black range
	#if bbox!=[]:
	#	img = img[bbox[0]:bbox[2], bbox[1]:bbox[3]]
	if w/h!=1920.0/1080.0:
		w1,h1 = img.size
		w1, h1 = float(w1), float(h1)
		print("360p or 648p.")
		scale_w = w1/360.0
		scale_h = h1/270.0 
		img = img.resize((360,270))
	else:
		w1,h1 = img.size
		w1, h1 = float(w1), float(h1)
		print("864p or 1920p.")
		scale_w = w1/1920.0
		scale_h = h1/1080.0 
		img = img.resize((1920,1080))

	#assert(scale_w==scale_h) 
	img.save("test.jpg")
	return img, w, h, scale_w, scale_h


def checkError(range_list, totalframes, fps):
	print("----")
	print(range_list)
	range_new = []
	for item in range_list:
		print(item)
		if item[1]-item[0]<fps*1.8 or item[0]>=totalframes or item[0]<0 or item[1]<=0:
			#range_list.remove(item)
			continue
		range_new.append(item)

	#return range_list
	return range_new

if __name__ == "__main__":
	a=  [[13463, 17713], [22513, 22888], [23963, 24463], [25413, 26513], [27713, 28138], [29738, 29788], [32238, 32538], [33138, 33563], [34188, 34838], [35288, 35613], [35788, 36238], [36338, 36688], [36838, 37263], [37513, 37913], [38138, 38463], [38863, 39413], [40263, 41188], [41913, 42213], [42813, 42938], [43338, 43613], [44013, 44088], [1000000, 0]]
	print(a)
	b = checkError(a, 45109, 25)
	print(b)
	out = overlap.dilate(b, 8)
	print(out)

