
# -*- coding: utf-8 -*-
import sys
#import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
import os
# os.environ['CUDA_VISIBLE_DEVICES']='0'
#import ocr
import time
import shutil
import numpy as np
from PIL import Image
from glob import glob
import cv2
import os

import json
import shutil
import cv2
from  datetime  import  *
import time
import traceback
from PIL import Image
sys.path.append("./pyscripts")
#import comm_log
import numpy as np
import math
#from demo import *
import jieba
from pydub import AudioSegment

from loadorigintxt_1s import *

def recogtext(im,savepath):#img is cv2 format
    #recog subtext
    print(savepath)
    cv2.imwrite(savepath,im)
#    tmp = Image.fromarray(cv2.cvtColor(im,cv2.COLOR_BGR2RGB))
#    tmp.save(savepath)
#    image = np.array(tmp)
#    result, image_framed, text_recs = ocr.model(image)
#    Image.fromarray(image_framed).save(savepath)
#
    segment = []
#    for key in result:
#        print(result[key][1])
#
#        #fenci
#        segs = jieba.cut(result[key][1]) 
#        for seg in segs:
#            if len(seg) > 1 and seg != '\r\n':
#                segment.append(seg)
#    print(segment)

#    return result, segment 
#    return 0, segment 
    return 0,0

def subtext_seg(shots_path, video_path, wavstop_path, subtextstop_path):
    #print("2")
    try:
        print(video_path)

        cap = cv2.VideoCapture(video_path)

        total_frames_num = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        print("total num=%d"%total_frames_num)

        fps=int(cap.get(cv2.CAP_PROP_FPS))
        print("-fps = "+str(fps))

    #load shots info
        print(shots_path)
        shots_dict = json.load(open(shots_path,'r'))
        clip_list=[]
        videoname=None
        for key in shots_dict.keys():
            shots_dict=shots_dict[key]
            videoname=key #***.mp4
            clip_list=shots_dict["shots"]

        clip_list2=[]
        last_end = clip_list[0][1]
        for i in range(len(clip_list)):
            shot=clip_list[i]
            clip_list2.append(shot)
            if shot[0]==shot[1]:#delete same start and end shot!!!!!!!!!
               print("error: same start and end shot!")#continue
               continue
            if i==0:
               continue

            if shot[0]>shot[1]:
               print(str(shots_path)+" error, start>end:  " +str(shot))
               exit()
            if shot[0]<=last_end:
               print(str(shots_path)+" error, current start<=last_end:  " +str(shot))
               exit()
            last_end=shot[1]

        clip_np = np.concatenate(clip_list2).tolist()
        print("shots:")
        print(type(clip_np))
    # end loading shots info 
        #print("2_1")

#load wav stop json file
        stop_dict = json.load(open(wavstop_path,'r'))
        wav_stop=[]
        videoname=None
        for key in stop_dict.keys():
            stops=stop_dict[key]
            videoname=key #***.mp4
            wav_stop=stops["stops"]

        print("wav stop_list")
        print(wav_stop)
        assert(len(clip_list)-1==len(wav_stop))

#load text stop json file
        subtextstop=[]

        substop_dict = json.load(open(subtextstop_path,'r'))
        videoname=None
        for key in substop_dict.keys():
            stops=substop_dict[key]
            videoname=key #***.mp4
            subtextstop=stops["txtstop"]

        print("subtext stop_list")
        print(subtextstop)

#########################

        num=-1
        sucess=True
        shot_num = 0
        frames=[]
        label=0
        samestory_pos=[] # subtext same or not in shot boundary, recording postion in video
        num_gap=-1

        flag=True
        seg_start = 0
        seg_end = -1
        strnd_count_story = 0
        count_story = 0


        wav_path = "xinwen2/wav/"+vid+".wav"
        mp3list=[]
        last_s = 0
        mp3 = AudioSegment.from_file(wav_path)#

        fourcc = cv2.VideoWriter_fourcc('I', '4', '2', '0')
        ##out = cv2.VideoWriter(videoname_seg,fourcc, fps)
        writepath = frames_folder+"/"+str(strnd_count_story)+"_"+str(last_s)+".mp4"
        #out = cv2.VideoWriter(writepath,fourcc, fps,(180,130) )

        while sucess:
            num+=1
            sucess,im0 = cap.read() # get next frame
	    #crop 
            if not sucess:
                break
            im1 = cv2.resize(im0,(180,130))
            #out.write(im1)

            im=im0#[330:420,120:620]
            frames.append(im)
            #print("3")

            # find in shots boundary 
            if num in clip_np:
                shot_num+=1
                if num<3:
                    continue
                if  shot_num%2==0:
                    # save shots imgs before shots interval 
                    print("-----------")
                    savepath=frames_folder+"/"+str(num)+"_0_shot"+str(shot_num/2)+"_st"+str(count_story)+"_stext"+str(strnd_count_story)+".jpg"
                    res, segments = recogtext(frames[-1], savepath)
                    savepath=frames_folder+"/"+str(num-1)+"_0_shot"+str(shot_num/2)+"_st"+str(count_story)+"_stext"+str(strnd_count_story)+".jpg"
                    res, segments = recogtext(frames[-2], savepath)
                    savepath=frames_folder+"/"+str(num-2)+"_0_shot"+str(shot_num/2)+"_st"+str(count_story)+"_stext"+str(strnd_count_story)+".jpg"
                    res, segments = recogtext(frames[-3], savepath)
                    label=0
                    flag=True

                else:
                    num_gap+=1
 
                    print(str(num)+"------")
                    if (wav_stop[num_gap]==1):# (subtextstop[num_gap]==1):
                        seg_end = num
                        count_story += 1
                        #if (subtextstop[num_gap]==1):
                    if (subtextstop[num_gap]!=0):
                        strnd_count_story += 1
                        # #out video and wav
                        filename=frames_folder+"/"+str(strnd_count_story-1)+"_"+str(last_s)+"_"+str(num-1)+".wav"
                        print("#### wav path="+filename)
                        #mp3[int(last_s*1000/fps):int((num-1)*1000/fps)].export(filename, format="wav")

                        #if strnd_count_story!=1:
                        #out.release()

                        writepath = frames_folder+"/"+str(strnd_count_story)+"_"+str(last_s)+".mp4"
                        #out = cv2.VideoWriter(writepath,fourcc, fps, (180, 130))
                        print("**** video path="+writepath)

                        # end #out video and wav
                        mp3list.append([last_s, num-1])
                        last_s = num


                    # save another more 2 imges after shots 
                    savepath=frames_folder+"/"+str(num)+"_1_shot"+str(shot_num/2)+"_st"+str(count_story)+"_stext"+str(strnd_count_story)+".jpg"
                    label +=1 
                    res, after_segments = recogtext(im,savepath)
                    flag=False
            
                continue


            # after shots boundary, ocr: find sub_text content
            # save shots imgs after shots interval 
            if label<3 and flag==False:
                savepath=frames_folder+"/"+str(num)+"_1_shot"+str((shot_num/2))+"_st"+str(count_story)+"_stext"+str(strnd_count_story)+".jpg"
                label +=1 
                res, after_segments = recogtext(im,savepath)


        cap.release()
        print("-youxiao frames = "+str(num))
        print("story clips:")
        print(mp3list)

    except Exception as e:
        print(traceback.format_exc())
        print(e)

    return 0



#def processtxt(txtpath,vid,shotstxtpath):
## txt 
#    rangetxt_1s = loadtext_1s(txtpath,vid)
#    print("1s_range:")
#    print(rangetxt_1s)
#
#    obj = loadtxt()
#    rangetxt_shots = obj.combine_txt_tv(shotstxtpath,vid)
#    print("shots_range:")
#    print(rangetxt_shots)
#
#    mer = rangetxt_1s+rangetxt_shots
#    
#    obj2 = MergeRange()
#    out = obj2.merge(mer)
#    print("--merge--")
#    print(out)
#    out_range = {}
#    out_range['range']=out
#    json.dump(out_range, open("json/"+vid+"_subtxt_range_1s.json",'w'))
#		return out
# end txt 


#
#/usr/local/qqwebsrv/python-2.7.8/bin/python loadorigintxt_1s.py "xinwen2/ocr_1s/ocr_1s_"$vid".txt" $vid $vid_imgtxt
#/usr/local/qqwebsrv/python-2.7.8/bin/python loadoriginsound.py $vid "json/"$vid"_subtxt_range_1s.json"
#/usr/local/qqwebsrv/python-2.7.8/bin/python make_soundstop.py "json/"$vid"_txt.json" xinwen2/A_out_data_storys/shots_$vid $vid "json/"$vid"_subtxt_range_1s.json" $vid"_soundpatch_1s.json" 
#/usr/local/qqwebsrv/python-2.7.8/bin/python story_clip_main.py xinwen2/video/$vid $vid_shots $vid_wavstop $vid_txtstop


def main():
    #print("1")
    video_path=sys.argv[1]#xinwen2/xinwen1 #os.path.join('/data2/phoebezhu/code/ClipShots_basline/20190215184605',line.split('/')[-1].strip('\n\r')+'.json')
    shots_path = sys.argv[2]
    wavstop_path = sys.argv[3]
    subtextstop_path = sys.argv[4]

    global vid
    vid = video_path.split("/")[-1]
    global frames_folder
    frames_folder = "./data_storys/shots_"+vid
    if os.path.exists(frames_folder)==False:
        os.makedirs(frames_folder)
    else:
        shutil.rmtree(frames_folder)
        os.makedirs(frames_folder)
    if os.path.exists(video_path):
        subtext_seg(shots_path, video_path, wavstop_path, subtextstop_path)
        print ('{} is done! {}')

if __name__ == '__main__':
    #comm_log.init("subtext_seg")
    main()
