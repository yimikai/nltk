# test code:
#  inout video_vid 
#  out : shots.json and shots images into data_storys/shots_$vid

#! /bin/bash
function read_dir(){
for file in `ls $1` 
do
 if [ -d $1"/"$file ] 
 then
 read_dir $1"/"$file
 else
 echo $file
 vid=$file 
 echo $vid
 #/data1/anaconda3/bin/python3.6 shots_client_line_2_test.py --gap=1 --use_th=0 --http_port=10001 \
 # --video_path="xinwen2/video_online/"$vid  #xinwen2/video_online/v000039nwui.MPHe10006.1.mp4
 #/usr/local/qqwebsrv/python-2.7.8/bin/python getshots_img.py "xinwen2/video0821/"$vid xinwen2/shots0821/$vid"_shots.json" #save shots images into data_storys/shots_$vid
 /usr/local/qqwebsrv/python-2.7.8/bin/python getshots_img.py "xinwen2/video_yuebing/"$vid xinwen2/shots_yuebing/$vid"_shots.json" #save shots images into data_storys/shots_$vid



 fi
done
} 

read_dir $1


