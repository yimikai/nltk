import numpy as np
import pyscripts.comm_log as comm_log
import math
import json

def assert_sound(sound_content, vid):
	#comm_log.info("sound_content"+str(sound_content))
	if len(sound_content)!=0:
		sound={}
		sound[vid]=sound_content
		json.dump(sound, open("./json/soundtxt/"+vid+"_soundtxt.json",'w'))
		return True, sound_content
	else:
		comm_log.info("Warning: sound content is not avalibale.")
		return False, []


def assert_shotsinfo(shot_content, vid):
#load shots info
	comm_log.info("shot_content= "+str(shot_content))
	clip_list=shot_content["shots"]
	clip_list2= []

	last_end = clip_list[0][1]
	for i in range(len(clip_list)):
		shot=clip_list[i]
		if shot[0]==shot[1]:#delete same start and end shot!!!!!!!!!
		   comm_log.info("error: same start and end shot!")#continue
		   continue
		if shot[0]>shot[1]:
		   comm_log.info(" error, start>end:  " +str(shot)+" vid="+str(vid))
		   #exit()
		   #return False, None
		   continue
		if (i!=0) and (shot[0]<=last_end):
		   comm_log.info(" error, current start<=last_end:  " +str(shot)+" vid="+str(vid))
		   #exit()
		   continue
		if shot[1]-shot[0]>3:
			clip_list2.append(shot)
		last_end=shot[1]

	clip_list_1 = np.concatenate(clip_list).tolist()
	shots_c = {}
	shots_c["shots"] = clip_list2
	return True, shots_c


def assert_1stxt(txt1s_content, fps, label="frame"):
	comm_log.info("txt1s_content"+str(txt1s_content))
	if label=="frame":
		return True, txt1s_content
	elif label=="second":
		fps = float(fps)
		txt1s_content_new = []
		for content in sorted(txt1s_content,key=lambda content:int(content["path"].split(".jpg")[0]),reverse=False):
			#comm_log.info(content)
			index = int(content["path"].split(".jpg")[0])
			frame_index =int(math.ceil(fps/2) + (index-1)*fps)
			content["path"] = str(frame_index)+".jpg"
			comm_log.info("1stransfer: second="+str(index)+" frame_index"+str(frame_index)+" fps="+str(fps))
			txt1s_content_new.append(content)
		return True, txt1s_content_new
