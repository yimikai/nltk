#!/usr/bin/env python
# coding=utf-8

import os
import sys
import logging
import logging.handlers
import comm_loghandler


class ContextFilter(logging.Filter):
    """
    This is a filter which injects contextual information into the log.

    Rather than use actual contextual information, we just use random
    data in this demo.
    """

    def filter(self, record):
        return 0 if record.levelno >= logging.ERROR else 1


logger = logging.getLogger('commlog')


def init(name, log_level=logging.DEBUG):
    """
    """
    log_path = "./logs"
    normal_log_file = log_path + '/' + name + '.log'
    warning_log_file = log_path + '/' + name + '.log.warning'

    logger.setLevel(log_level)
    normal_hdlr = comm_loghandler.MyHandler(normal_log_file,
                                                            when='D',
                                                            interval=1,
                                                            backupCount=30)
    normal_hdlr.setLevel(log_level)
    formatter = logging.Formatter('%(asctime)s\t%(message)s')
    normal_hdlr.setFormatter(formatter)
    normal_hdlr.addFilter(ContextFilter())

    # Make WF log emit to a seperate file
    # set wf log file
    warning_hdlr = logging.handlers.TimedRotatingFileHandler(warning_log_file,
                                                             when='D',
                                                             interval=1,
                                                             backupCount=30,
                                                             encoding="utf-8")
    formatter_warn = logging.Formatter('%(asctime)s\t%(lg_filename)s:%(lg_line_num)s:%(lg_funcName)s\t%(message)s')
    warning_hdlr.setFormatter(formatter_warn)
    warning_hdlr.setLevel(
        log_level if log_level > logging.ERROR else logging.ERROR)

    logger.addHandler(warning_hdlr)
    logger.addHandler(normal_hdlr)


def debug(msg):
    """
    debug info
    :param msg:
    :type msg: str
    :return:None
    :rtype:None
    """
    if msg is not None:
        logger.debug(msg, extra=_extra())


def info(msg):
    """
    info msg
    :param msg:
    :type msg: str
    :return: NOne
    :rtype:None
    """
    if msg is not None:
        logger.info(msg, extra=_extra())


def warning(msg):
    """
    warning msg
    :param msg:
    :type msg: str
    :return:
    :rtype:None
    """
    if msg is not None:
        logger.warning(msg, extra=_extra())


def error(msg):
    """
    error msg
    :param msg:
    :type msg: str
    :return:None
    :rtype:None
    """
    if msg is not None:
        logger.error(msg, extra=_extra())


def critical(msg):
    """
    critical msg
    :param msg:info
    :type msg:str
    :return:None
    :rtype:None
    """
    if msg is not None:
        logger.critical(msg, extra=_extra())


def _extra():
    """
    add file name, file number and function name
    :return: log info dict
    :rtype:dict
    """
    depth = sys._getframe().f_code.co_stacksize - 1
    frame = sys._getframe(depth)
    file_path = frame.f_code.co_filename
    dir_path, base_name = os.path.split(file_path)
    super_dir, current_dir = os.path.split(dir_path)
    file_name = os.path.join(current_dir, base_name)
    return {'lg_filename': file_name,
            'lg_line_num': frame.f_lineno,
            'lg_funcName': frame.f_code.co_name}


if __name__ == "__main__":
    init('test')
    init('test')
    for i in range(5):
        error("yyyy")
    critical("Database has gone away")

    for i in range(5):
        info("xxxx")

        # import mysql
        # mysql = mysql.Mysql(0)

        # i = 0
        # p1 = t1('p1')
        # p1.start()
        # p2 = t2('p2')
        # p2.start()
        # import my_mysql
        # mysql = my_mysql.Mysql(0)

