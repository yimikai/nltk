#--coding utf-8--
import os,sys
from PIL import Image
import json
import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
reload(sys) 
sys.setdefaultencoding('utf8')
import loadorigintxt
from loadorigintxt import *



def inrange(num):
    #rangetxtpath="b0875alm66w_subtxt_range.json"
    rangetxtpath=sys.argv[4]
    range_dict = json.load(open(rangetxtpath, 'r'))
    range_list = range_dict["range"]
    for item in range_list:
        print("item="+str(item))
        if item[0]<=num<=item[1]:
            print(str(num)+" in range ["+str(item)+"]")
            return True
    return False

def make_txtstop(txtpath, imgfolder, vid):
    dir=imgfolder
    count = -1
    last_shot=0
    last_txt=""
    last_color = ""
    sub_count=0
    txtstop_list=[]

    txtdict = json.load(open(txtpath,'r'))

    for root,dirs,files in os.walk(dir):
      #f = open(file,'w')
      print("folder= "+str(dirs))
      print('----------------')
      for file in sorted(files,key=lambda file:int(file.split("_")[0]),reverse=False):
            pth = os.path.join(root,file)
            print(pth)
            num = int(file.split("_")[0])

            #num = file.split("/")[-1].split("_")[-1].split(".jpg")[0]
            shot_num = float(file.split("/")[-1].split("_")[-1].split(".jpg")[0][4:])
            tmp=str(shot_num-0.5)
            if tmp.split(".")[-1]=="5": # cpmpare with befpre_shot
                last_txt = txtdict[file]["txt"]
                last_color = txtdict[file]["tag"]
                print("last_shot="+str(shot_num))

            if (tmp.split(".")[-1]=="0") and (shot_num!=last_shot): # cpmpare with befpre_shot
                print('----------------')
                print("shot="+str(shot_num))

                txt = txtdict[file]["txt"]
                color = txtdict[file]["tag"]

                if (txt!="") and (last_txt!="") and (txt==last_txt):
                    txtstop_list.append(0)
                elif (txt!="") and (last_txt!="") and (txt!=last_txt) and color=="blue" and last_color=="blue":
                    sub_count+=1
                    txtstop_list.append(1)
                    #print("*******different content. ")
                elif ((txt!="") or (last_txt!="")):
                    txtstop_list.append(0)
                elif inrange(num)==True:
                    txtstop_list.append(0)
                else:
                    print(pth+" ----No txt")
                    txtstop_list.append(-1)

                
            count = count +1
            last_shot = shot_num
    print(count)
    
    print(txtstop_list)
    print(len(txtstop_list))
    txtstop_dict={}
    txtstop_dict["txtstop"]=txtstop_list
    out_dict={}
    out_dict[vid]=txtstop_dict
    json.dump(out_dict, open(vid+"_txtstop.json",'w'))




if __name__ == '__main__':
        txtpath = sys.argv[1]
        imgfolder = sys.argv[2]
        vid = sys.argv[3]
        make_txtstop(txtpath, imgfolder, vid)
        #txt = loadtext(txtpath,vid)
        #print(txt)
