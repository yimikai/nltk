# -*- coding: utf-8 -*-
import os,sys
from PIL import Image
import json
import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
reload(sys) 
sys.setdefaultencoding('utf8')

from PIL  import Image, ImageDraw
from getcolor import *
import re
import string
from mergeRange import *


class loadtxt():
    def __init__(self):
        pass

    def subtxt(self, line_box_i, img, imgpath):
    
        x0 = line_box_i[0]
        h0 = 270-line_box_i[7]
        h = line_box_i[7]-line_box_i[1]
        w = line_box_i[2]-line_box_i[0]
        if (60<x0<90) and (8<h0<28) and (15<h<30) and (30<w<300):
            img0 = img.crop((line_box_i[0]+5, line_box_i[1]+5,line_box_i[2]-5,line_box_i[7]-5))
            # subtxt or speaker
            tag = get_color(img0)
            height = line_box_i[7] - line_box_i[1]
            width = line_box_i[3] - line_box_i[0]
            return True, tag, height, width
        else:
            return False, "-1", -1, -1
    
    def find_range(self, file, min_subtxt, max_subtxt, last_subtxt, content_txt, subtxt_range, tmp_txt):
    #10171_1_shot126.5.jpg
        index = int(file.split("_")[0])
    
        if last_subtxt!=content_txt:
            if last_subtxt in tmp_txt.keys():#tmp_txt[last_subtxt]:
                if min_subtxt > tmp_txt[last_subtxt][0]:
                    min_subtxt =tmp_txt[last_subtxt][0]
                if max_subtxt < tmp_txt[last_subtxt][1]:
                    max_subtxt =tmp_txt[last_subtxt][1]
            tmp_txt[last_subtxt]=[min_subtxt, max_subtxt]
            subtxt_range.append([min_subtxt, max_subtxt])
            return index,index,content_txt, subtxt_range, tmp_txt # next story range
    
        if min_subtxt > index:
            min_subtxt =index
        if max_subtxt < index:
            max_subtxt =index
    
        return min_subtxt,max_subtxt,content_txt, subtxt_range, tmp_txt
    
    def sort_path(self, txt_dict):
        for item in sorted(txt_dict,key=lambda item:int(item["path"].split("_")[0]),reverse=False):
            #print(item["path"])
            #print(item["txt"])
            q=1
    
    def loadtext(self, txtpath,vid):
        out_txt={}
        out_range={}
        
        tmp_txt={}
    
        txt_dict = json.load(open(txtpath,'r'))
       # txt_dict = sort_path(txt_dict):
        txtstop_list = []
    
        subtxt_range = []
    
        min_subtxt =1000000
        max_subtxt = 0
        last_subtxt = ""
        #for i in range(len(txt_dict)):
    
    
        lastpatch=[]
    
        count=-1
        for content in sorted(txt_dict,key=lambda content:int(content["path"].split("_")[0]),reverse=False):
            #print(content["path"])
            #content = txt_dict[i]
            #print("---for 1 img-----"+content["path"])
            imgpath = "xinwen2/A_out_data_storys/shots_"+vid+"/"+content["path"]
            #print(imgpath)
            img = Image.open(imgpath)
            #print(content)
            #print("\n")
    
            text_dict = content["txt"]
            #print(text_dict)
    
            content_txt=''
            tag_content = "-1"
            for key in text_dict.keys(): #key is order index, meaning how many text-lines 
                line_text_dict = text_dict[key]
                #print(line_text_dict)
                line_box_i = line_text_dict['line_box']
                #print(line_box_i)
    
                flag, tag, height, width = self.subtxt(line_box_i, img, imgpath)
                if flag==True:
                    content_txt = line_text_dict['txt'].strip()
                    #content_txt = clean_space(content_txt)
                    content_txt = "".join(content_txt.split())
                    #content_txt = "".join(c for c in content_txt if c not in string.punctuation)
                    content_txt = ''.join(re.findall(u'[\u4e00-\u9fff]+', content_txt))
    
                    tag_content=tag
                    #print("height = "+str(height) +" color = "+tag)
                    count+=1
    
                    #if (count==0) and (tag=="blue") and (height==20 or height==24):
		    if (count==0) and (tag=="blue") and (25< height<38):
                        last_subtxt = content_txt
                        continue
    
                    #if (tag=="blue") and (height==20 or height==24 or abs(height-18)<2): # record subtxt 
		    if (tag=="blue") and (24< height<40): # record subtxt 
                        min_subtxt,max_subtxt, last_subtxt, subtxt_range, tmp_txt = self.find_range(content["path"], min_subtxt, max_subtxt, last_subtxt, content_txt, subtxt_range, tmp_txt)
            
            out_txt[content['path']]={"txt":content_txt,"tag":tag_content}
    
        s=sorted(tmp_txt.items(),key=lambda x:x[1][0])
        out=[]
        s_all=[]
    
        #print("----sorted ----")
        last_txt=''
        for i in range(len(s)):
            if s[i][1][0]!=s[i][1][1]:
                #print(s[i][1])
    
                txt = s[i][0]
                txt = "".join(txt.split())
    
                tmp={}
                tmp["txt"]=txt
    
                minp = s[i][1][0]
                maxp = s[i][1][1]
                #if txt.find("央视记者")!=-1:
                if txt.find("央视")!=-1 or txt.find("报道")!=-1:
                    minp=out[-1][0] 
                    out.pop()
                    s_all.pop()
                    tmp["txt"]=last_txt
                out.append([minp-15, maxp+15])
                tmp["range"]=[minp, maxp]
                s_all.append(tmp)#=[minp, maxp]
    
                last_txt=txt
    
             #print(content_txt)
        obj = MergeRange()
        out = obj.merge(out)
        out_range['range']=out
    
        #print(out)
        json.dump(out_txt, open(vid+"_txt.json",'w'))
        json.dump(out_range, open(vid+"_subtxt_range.json",'w'))
    
        #return out_txt #txtstop_list
        return out #txtstop_list
    

if __name__ == '__main__':
    txtpath = sys.argv[1]
    vid = sys.argv[2]
    obj = loadtxt()
    txt = obj.loadtext(txtpath,vid)
    #print(txt)
    #txt_dict = json.load(open(txtpath,'r'))
    #sort_path(txt_dict)
    #print(txt)
