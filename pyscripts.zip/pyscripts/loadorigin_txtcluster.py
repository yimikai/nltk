#--coding utf-8--
import os,sys
from PIL import Image
import json
import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
reload(sys) 
sys.setdefaultencoding('utf8')

from PIL  import Image, ImageDraw
from getcolor import *
from pydub import AudioSegment
import re
from searchInsert import *

def loaddict2list(path):
    shots_dict = json.load(open(path,'r'))
    clip_list=shots_dict["range"]
    clips = np.concatenate(clip_list).tolist()
    print(clips)
    return clips

def splitsoundbytxtrange(nums, pos_s, pos_e):
    flag = False
    gap = abs(pos_e-pos_s)
    # overlap different subtext, so this patch should be deletedt
    if gap>=5:
        flag = True
        num = int(gap/2)-1
        return flag, num
    if gap>=4:
        flag = True
        num = int(gap/2)-1
        return flag, num
    if gap>=3 and pos_s%2!=0:
        flag = True
        num = int(gap/2)
        return flag, num
    return flag, 0

def findrangeOverlap(start, end):
    txtrangepath = sys.argv[2]
    nums = loaddict2list(txtrangepath)
    print("txt range:")
    print(nums)
    ob = Search(nums)
    print("find sound: start="+str(start)+" end="+str(end))
    pos_s = ob.searchInsert(start)
    #pos_s = searchInsert(nums, start)
    pos_e = ob.searchInsert(end)
    # whether including more than 1 txtrange, and get how many clip_postion 
    flag, num = splitsoundbytxtrange(nums, pos_s, pos_e) 
    print("insert pos: pos_s="+str(pos_s)+" pos_e="+str(pos_e))
    return flag, num


def loadsoundtext_cluster(vid):
    #wav_path="xinwen2/wav/b0875alm66w.wav"
    wav_path="xinwen2/wav/"+vid+".wav"
    mp3 = AudioSegment.from_file(wav_path)#

    soundpath = "xinwen2/txtcluster/sound_"+vid
    txt_dict = json.load(open(soundpath,'r'))


    soundpatch = {}
    patch=[]
    for content in sorted(txt_dict,key=lambda content:int(content["order"]),reverse=False):
        index = content["order"]
        #print("---for "+str(index)+" sound-----")
        text_dict = content["txt"]
        #text_dict = "".join(text_dict.split()).encode('utf-8').strip()
        text_dict = "".join(text_dict).encode('utf-8').strip()
        #text_dict = "".join(re.findall(u'[\u4e00-\u9fff]+', text_dict)).encode('utf-8').strip()
        print(text_dict)

        start_time = int(content["time_split"]["start_time"])
        end_time = int(content["time_split"]["end_time"])
        #start_time = float(content["time_split"]["start_time"])*25/1000 #frame  number
        #end_time = float(content["time_split"]["end_time"])*25/1000

        filename = str(content["order"])+".wav"
        mp3[start_time:end_time].export(filename, format="wav")

        start = int(start_time*15/1000)
        end = int(end_time*15/1000)
        flag, num = findrangeOverlap(start+10, end-10)
        if flag==False:
            patch.append([start,end])
        
        if flag==True:
            print("overlap : start="+str(start)+" end="+str(end))

    soundpatch["soundtxt_cluster_range"]=patch
    json.dump(soundpatch, open(vid+"_soundpatch_1s.json",'w'))

    return 


if __name__ == '__main__':
        vid = sys.argv[1]
        loadsoundtext(vid)
