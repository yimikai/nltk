# -*- coding: utf-8 -*-
import os,sys
import subprocess
sys.path.append("./pyscripts/")
from Classify import *
from getcolor import *
from IntervalIntersection import *
import txtmatching as simi

def fuzzy_matching(s):
	tmp_txt={}
	out=[]
	s_all=[]
	print("----sorted ----")
	last_txt=''
	for i in range(len(s)):
	    if s[i][1][0]!=s[i][1][1]:
	
	        txt = s[i][0]
	        txt = "".join(txt.split())
	
	        tmp={}
	        tmp["txt"]=txt
	
	        minp = s[i][1][0]
	        maxp = s[i][1][1]
	        print(txt +" ["+str(minp)+","+str(maxp)+"]")
	        if simi.gettxtsimi(last_txt, txt)>0.6:
                    print("similar: ")
                    print(txt)
                    print(last_txt)
                    print("end similar.")
	            minp=out[-1][0] 
	            out.pop()
	            s_all.pop()
	            tmp["txt"]=last_txt
	        #out.append([minp-15, maxp+15]) # add another more half second
	        out.append([minp, maxp]) # add another more half second
	        tmp["range"]=[minp, maxp]
        	tmp_txt[tmp["txt"]]=[minp, maxp]

	        s_all.append(tmp)#=[minp, maxp]
	
	        last_txt=tmp["txt"]
	return out, tmp_txt


def sort_merge(s):
	tmp_txt={}
	out=[]
	s_all=[]
	print("----sorted ----")
	last_txt=''
	for i in range(len(s)):
	    if s[i][1][0]!=s[i][1][1]:
	
	        txt = s[i][0]
	        txt = "".join(txt.split())
	
	        tmp={}
	        tmp["txt"]=txt
	
	        minp = s[i][1][0]
	        maxp = s[i][1][1]
	        print(txt +" ["+str(minp)+","+str(maxp)+"]")
	        if txt.find("央视")!=-1 or txt.find("报道")!=-1 or txt.find("记者")!=-1:

	            if out==[]: 
	                minp = s[i][1][0]
	            else:
	                minp=out[-1][0] 
	                out.pop()
	                s_all.pop()
	            tmp["txt"]=last_txt
	        #out.append([minp-15, maxp+15]) # add another more half second
	        out.append([minp, maxp]) # add another more half second
	        tmp["range"]=[minp, maxp]
        	tmp_txt[tmp["txt"]]=[minp, maxp]

	        s_all.append(tmp)#=[minp, maxp]
	
	        last_txt=tmp["txt"]
	return out, tmp_txt

def run_shell(cmd):
  try:
    res = subprocess.check_output(cmd, shell=True)
    return True, res.strip()
  except subprocess.CalledProcessError, e:
    return False, e.output.strip()

def television(key,vid, label, zhuchiren_content):
	obj = Classify(key, vid, label, zhuchiren_content)
	flag = obj.classify()
	if flag == "tv":
	    return True
	else:
	    return False


#def check(range_list):
#	for item in range_list:
#		if item[0]>=item[1]:
#			range_list.remove(item)
#	return range_list


def subtxt(line_box_i, img, scale_w, scale_h, index):
    x0 = line_box_i[0]
    h0 = 486-line_box_i[7]
    h = (line_box_i[7]-line_box_i[1])
    w = (line_box_i[2]-line_box_i[0])
    print("x0 h0 h w = "+str(x0)+" "+str(h0)+" "+str(h)+" "+str(w))
    #if (60<x0<90) and (8<h0<28) and (15<h<30) and (30<w<300):
    if (100<x0<150) and (24<h0<60) and (15<h<40) and (30<w<580):
        img0 = img.crop((line_box_i[0] + 10, line_box_i[1]+5,line_box_i[2]-5,line_box_i[7]-5))
	img0.save("test/"+str(index)+".jpg")
        # subtxt or speaker
        tag = get_color(img0, 486)
        height = (line_box_i[7] - line_box_i[1])/1 #scale_h
        width = (line_box_i[3] - line_box_i[0])/1 #scale_w
        return True, tag, height, width
    else:
        return False, "-1", -1, -1

# process 1920*1080 scale img
def subtxt2(line_box_i, img, scale_w, scale_h, index):
    print("check ocr format  for 1080*1920 img ")
    x0 = line_box_i[0]/scale_w
    h0 = 1080-line_box_i[7]/scale_h
    h = (line_box_i[7]-line_box_i[1])/scale_h
    w = (line_box_i[2]-line_box_i[0])/scale_w
    print("x0 h0 h w = "+str(x0)+" "+str(h0)+" "+str(h)+" "+str(w))
    #if (60<x0<90) and (8<h0<28) and (15<h<30) and (30<w<300):
    #if (526<x0<720) and (60<h0<118) and (36<h<90) and (30<w<1180):
    if (526<x0<720) and (60<h0<118) and (36<h<90) and (30<w<1180):
        img0 = img.crop((int(line_box_i[0]/scale_w + 10), int(line_box_i[1]/scale_h+5),int(line_box_i[2]/scale_w-5),int(line_box_i[7]/scale_h-5)))
	img0.save("test/"+str(index)+".jpg")
        # subtxt or speaker
        tag = get_color(img0, 1920)
        height = h
        width = w
        return True, tag, height, width
    else:
        return False, "-1", -1, -1

def subtxt0(line_box_i, img, scale_w, scale_h, index, origin_width, origin_height ,bbox):
    if origin_width==1920 or origin_width==864: # 1920*1080
	return subtxt2(line_box_i, img, scale_w, scale_h, index)

    if bbox!=[]:
        black_h = origin_height - bbox[3]
        x0 = line_box_i[0]/scale_w - bbox[0]/scale_w
        h0 = 270-(line_box_i[7])/scale_h - black_h/scale_h
        h = (line_box_i[7]-line_box_i[1])/scale_h
        w = (line_box_i[2]-line_box_i[0])/scale_w

    else:
        x0 = line_box_i[0]/scale_w
        h0 = 270-line_box_i[7]/scale_h
        h = (line_box_i[7]-line_box_i[1])/scale_h
        w = (line_box_i[2]-line_box_i[0])/scale_w
    print("x0 h0 h w = "+str(x0)+" "+str(h0)+" "+str(h)+" "+str(w))
    #if (60<x0<90) and (8<h0<28) and (15<h<30) and (30<w<300):
    #if (50<x0<90) and (8<h0<30) and (15<h<30) and (30<w<310):
    #if (50<x0<90) and (8<h0<30) and (10<h<30) and (26<w<315):
    # last line of subtxt
    if (50<x0<110) and (8<h0<30) and (10<h<30) and (26<w<315):
        img0 = img.crop((int(line_box_i[0]/scale_w + 10), int(line_box_i[1]/scale_h+5),int(line_box_i[2]/scale_w-5),int(line_box_i[7]/scale_h-5)))
	img0.save("test/"+str(index)+".jpg")
	print(img0.size)
        # subtxt or speaker
        tag = get_color(img0, 360)
        height = (line_box_i[7] - line_box_i[1])/scale_h
        width = (line_box_i[3] - line_box_i[0])/scale_w
        return True, tag, height, width
    else:
        return False, "-1", -1, -1



#def find_range(file, min_subtxt, max_subtxt, last_subtxt, content_txt, subtxt_range, tmp_txt, index):
#
#    if last_subtxt!=content_txt:
#        if last_subtxt in tmp_txt.keys():#tmp_txt[last_subtxt]:
#            if min_subtxt > tmp_txt[last_subtxt][0]:
#                min_subtxt =tmp_txt[last_subtxt][0]
#            if max_subtxt < tmp_txt[last_subtxt][1]:
#                max_subtxt =tmp_txt[last_subtxt][1]
#        tmp_txt[last_subtxt]=[min_subtxt, max_subtxt]
#        subtxt_range.append([min_subtxt, max_subtxt])

def find_range(file, min_subtxt, max_subtxt, last_subtxt, content_txt, subtxt_range, tmp_txt, index):

    if last_subtxt!=content_txt:
        if last_subtxt in tmp_txt.keys():#tmp_txt[last_subtxt]:
            if min_subtxt > tmp_txt[last_subtxt][0]:
                min_subtxt =tmp_txt[last_subtxt][0]
            if max_subtxt < tmp_txt[last_subtxt][1]:
                max_subtxt =tmp_txt[last_subtxt][1]
        tmp_txt[last_subtxt]=[min_subtxt, max_subtxt]
        subtxt_range.append([min_subtxt, max_subtxt])
        return index,index,content_txt, subtxt_range, tmp_txt # next story range

    if min_subtxt > index:
        min_subtxt =index
    if max_subtxt < index:
        max_subtxt =index

    return min_subtxt,max_subtxt,content_txt, subtxt_range, tmp_txt

def inrange_txt( num, range_list):
    for item in range_list:
        if item[0]<=num<=item[1]:
            return True
    return False


def deleteoveralllap( patch, trange):
	leftrange = []
	for item in patch:
		if self.overalllap(item, trange)==False:
			leftrange.append(item)
	return leftrange

def overalllap( item_list, leftrange):
	for item in leftrange:
		if (item_list[0]<=item[0]) and (item_list[1]>=item[1]):
			return True
	return False
	

def findintersection( soundrange, leftrange):
	obj = IntervalIntersection()
	section = obj.intervalIntersection(leftrange,soundrange)
	return section

# process txt_leftrange intersection with shots range and sound range
# 1. if sound and shots range can fill text_leftrange and only left 2 range, i.e 1 stop, then this stop is what we find story stop.
# 2. if if sound and shots range can fill text_leftrange and only left 1 range, we regard oterwise range as stop range which is what we find story stop.
# 3. if sound and shots range can fill text_leftrange and left more than 2 ranges, we discard inner parts and only record 1st and last part, inner range as stop range. 
def processstop(soundrange_left, shotsrange_left, merge_range, leftrange_txt):
	# if one is empty, then return another one range
	if (soundrange_left==[[]]) or (shotsrange_left==[[]]):
		print("empty retunr merge"+str(merge_range))
		return merge_range



	last_range = [] 
	for item in merge_range:
		if len(item)==2:
			last_range.append(item)
		elif len(item)==1 and (overalllap(item, leftrange_txt)==False):
			last_range.append(item)
		elif len(item)>2:
			#For future:  do something ... 
			# there's more stops but only stop is true
			# Now we have to record only first and last part and loss these parts
			last_range.append([item[0],item[-1]])
		elif len(item)==1 and (overalllap(item, leftrange_txt)==True):
			intersection = findintersection(shotsrange_left, [item])
			if overalllap(item, leftrange_txt)==True:
				intersection = findintersection(soundrange_left, [item])
			if 0<len(intersection)<=2:
				last_range.append(intersection)
			else:
				last_range.append([intersection[0],intersection[-1]])

	return last_range



