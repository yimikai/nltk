# -*- coding: UTF-8 -*-
'''
    author: tinaxtshi
    date: 2018/12/01
    function: black edge detection
'''
import cv2
import os,sys,traceback
import numpy as np
import time
import concurrent.futures


fps_num = 15

def imgBlackDetect(img,h,w):
    # input
    #   origin_path : img path
    #   h,w : size of img

    # return
    #   bbox : boundry of img [x1,y1,x2,y2]
    #   area_ratio : area_ratio of img (img_area/total_area)
    #   num : num of black edge

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    closed_1 = cv2.erode(gray, None, iterations=4)
    closed_1 = cv2.dilate(closed_1, None, iterations=4)
    blurred = cv2.blur(closed_1, (9, 9))
    #num = mode(blurred.flat)[0][0] + 8               # 阈值设置
    counts = np.bincount(blurred.flat)
    num = np.argmax(counts) + 3
    num = num if num <= 30 else 5
    _, thresh = cv2.threshold(blurred, num, 255, cv2.THRESH_BINARY)     # 图像二值化
    kernel = np.ones((5, 5), np.uint8)
    closed_2 = cv2.erode(thresh, kernel, iterations=2)
    closed_2 = cv2.dilate(closed_2, kernel, iterations=2)
    _, cnts, _ = cv2.findContours(closed_2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)    # 得到图像轮廓

    if cnts == []:
        bbox = [0,w,0,h]
        return bbox,1.0
    else:
        cnts_total = cnts[0]
        for num in range(1, len(cnts)):
            cnts_total = np.vstack((cnts_total, cnts[num]))
        xxs = [i[0][0] for i in cnts_total]
        yys = [i[0][1] for i in cnts_total]
        x1 = min(xxs) if min(xxs) > 0 else 0
        x2 = max(xxs)# if max(xxs) < w else w
        y1 = min(yys) if min(yys) > 0 else 0
        y2 = max(yys)# if max(yys) < h else h
        height = y2 - y1
        width = x2 - x1
        area_ratio = (height * width) / float(h * w)      # 计算面积占比

        return [x1, y1, x2, y2], area_ratio

def videoBlackDetect(path_list):
    # path_list: frame list of a video
    #    path_list = ['F:\\00heibian\\sibian\\o0720siuc13\\1.jpg','F:\\00heibian\\sibian\\o0720siuc13\\2.jpg','F:\\00heibian\\sibian\\o0720siuc13\\3.jpg']
    # return
    #   result_list :  [[img_idx,bbox,area_ratio,num_edge],[img_idx,bbox,area_ratio,num_edge],[img_idx,bbox,area_ratio,num_edge],......]

    try:
        result = []
        num=total=0
        area= [] 
        bbox_list = []
        
        for idx,path in enumerate(path_list):
            flag = 0
            total+=1
            print(path)
            img = cv2.imread(path)
            if idx == 0:
                (h,w,channel) = img.shape
            edge_ratio = 0.05
            threshold_h = edge_ratio * h
            threshlod_w = edge_ratio * w
            threshlod = [threshlod_w,threshold_h,threshlod_w, threshold_h]
            bbox,area_ratio = imgBlackDetect(img,h,w)     #bbox = [x1,y1,x2,y2]
            bbox_black = [bbox[0], bbox[1], w-bbox[2], h-bbox[3]]
            print("area ratio = "+str(area_ratio))
            if area_ratio< 0.8 and area_ratio >= 0.1:
                res = [(bbox_black[i] >= threshlod[i]) for i in range(4)]
                x_m = (bbox[0] + bbox[2]) / 2
                y_m = (bbox[1] + bbox[3]) / 2
                if abs(x_m - 0.5 * w) <= 0.1 * w and abs(y_m - 0.5 * h) <= 0.1 * h:
                    if res.count(True)>=3:
                        detect_result = [idx,bbox,area_ratio,res.count(True)]
                        result.append(detect_result)
                        flag = 1
                #if res.count(True)==2:
                #    if bbox[0]>=0.2*w and bbox[2]>=0.2*w:
                #        detect_result = [idx, bbox, area_ratio, res.count(True)]
                #        result.append(detect_result)
                #        flag = 0
            if flag == 1 or flag == 0:     # 识别到黑框，原图上画框，更改path可修改画框图像存储路径
                flag = 0
                cv2.rectangle(img, (int(bbox[0]), int(bbox[1])), (int(bbox[2]),int(bbox[3])), (0, 255, 0), 3) #画框
                print(bbox)
                #cv2.imwrite(path+"_1.jpg", img)     #path 可更改
                num+=1
                area.append(area_ratio)
                bbox_list.append(bbox)
        ratio = float(num)/total
        return result,ratio, np.mean(np.array(bbox_list), axis=0), np.mean(np.array(area))
        
    except Exception as e:
        traceback.print_exc()
        pass

def multi_process_crop(input_dir):            # 并发
    with concurrent.futures.ProcessPoolExecutor() as executor:
        executor.map(imgBlackDetect, input_dir)

def blackedge_video_detect(videopath1):


    video1 = cv2.VideoCapture(videopath1)

    if not video1.isOpened():
        print("video1 open error ")
        print(videopath1)
        return -1

    frame_counter =0

    result_sum = []
    detect_result_list = []


    while(1):

        ret1, frame1 = video1.read()
        flag = 0

        if not ret1:
            #print("frame1 is false")
            break

        if (frame_counter )%fps_num==8 :


            #cv2.imshow("video1",frame1)
            if frame_counter == 8:
                (h, w, channel) = frame1.shape

            edge_ratio = 0.05
            threshold_h = edge_ratio * h
            threshlod_w = edge_ratio * w
            threshlod = [threshlod_w, threshold_h, threshlod_w, threshold_h]
            threshlod_2 = [0.1*w, 0.1*h, 0.1*w, 0.1*h]
            bbox, area_ratio = imgBlackDetect(frame1, h, w)  # bbox = [x1,y1,x2,y2]
            bbox_black = [bbox[0], bbox[1], w - bbox[2], h - bbox[3]]
            print area_ratio

            if area_ratio < 0.8 and area_ratio >= 0.1:
                res = [(bbox_black[i] >= threshlod[i]) for i in range(4)]
                res_2 = [(bbox_black[i] >= threshlod_2[i]) for i in range(4)]
                x_m = (bbox[0] + bbox[2]) / 2
                y_m = (bbox[1] + bbox[3]) / 2
                if abs(x_m - 0.5 * w) <= 0.1 * w and abs(y_m - 0.5 * h) <= 0.1 * h:
                    if res.count(True) >= 3 and res_2.count(True) >= 1:
                        detect_result = [frame_counter/fps_num, bbox, area_ratio, res.count(True)]
                        #result_sum.append(detect_result)
                        flag = 1
                if res.count(True) == 2:
                    if bbox[0] >= 0.2 * w and bbox[2] >= 0.2 * w:
                        detect_result = [frame_counter/fps_num, bbox, area_ratio, res.count(True)]
                        #result_sum.append(detect_result)
                        flag = 0

            detect_result_list.append(flag)

            if flag == 1 or flag == 0:  # 识别到黑框，原图上画框，更改path可修改画框图像存储路径
                #flag = 0

                cv2.rectangle(frame1, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (0, 255, 0), 3)  # 画框

                #cv2.imwrite(path, img)  # path 可更改

            cv2.imshow("video1", frame1)

            if cv2.waitKey(1)== ord("q"):
                break

        frame_counter += 1

    result = 0
    img_num = len(detect_result_list)
    if img_num < 1 :
        print ('video length < 1s')
        return -1

    blackedge_num = sum(detect_result_list)

    black_duty = blackedge_num / float(img_num)

    print ('blackedge_num', blackedge_num, 'img_num', img_num)

    if black_duty > 0.33 and blackedge_num >=5:
        print ('------', 'this video is blackedge', black_duty, '------')
        result = 1
    else:
        print ('------', 'this video is normal', black_duty, '------')


    video1.release()
    cv2.destroyAllWindows()
    return result

def detectBlack(path1):
    time_start = time.time()
    hit_list = []
    try:

        if '.mp4' in path1 :

            result = blackedge_video_detect(path1)
            time_record1 = time.time() - time_start
            print ('time_record1', time_record1)

        else:
            file_num = 0
            hit_num = 0
            for root, dirs, files in os.walk(path1):
                for file in files:
                    filepath = os.path.join(root, file)
                    if '.mp4' in filepath:
                        file_num += 1
                        print ('******', filepath , '******')
                        result = blackedge_video_detect(filepath)
                        time_record1 = time.time() - time_start
                        print ('time_record1', time_record1)
                        if result == 1:
                            hit_num += 1
                            hit_list.append(file)
                        if file_num:
                            hit_rate = hit_num / float(file_num)
                            print ('hit rate', hit_rate, hit_num, file_num)

            if file_num < 1:
                image_path_list = []
                for root, dirs, files in os.walk(path1):
                    for file in sorted(files, key=lambda file: int(file.split("_")[-1].split(".jpg")[0])):
                        pathfndir = os.path.join(root, file)
                        image_path_list.append(pathfndir)

                result, ratioo, bbox, area_ratio = videoBlackDetect(image_path_list)
                print(ratioo)
                print(bbox)
                print(area_ratio)
                print("black ratio = "+str(ratioo))

                time_record1 = time.time() - time_start

                print ('time_record1', time_record1)
                return result,ratioo, bbox, area_ratio

        print hit_list
        #print ("result is %d" % result)
        print ("result is :")
        print (str(result))


    except Exception as e:
        traceback.print_exc()
        return 1,0, [], 0




if __name__ == '__main__':
    path1 = sys.argv[1]
    detectBlack(path1)

