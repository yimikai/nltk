
# -*- coding: utf-8 -*-
import sys
import importlib
importlib.reload(sys)
PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
import os
# os.environ['CUDA_VISIBLE_DEVICES']='0'
#import ocr
import time
import shutil
import numpy as np
from PIL import Image
from glob import glob
import cv2
import os

#import tensorflow as tf
##os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2"
##gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.333)
##sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
#import torch
#import torch._utils
#try:
#    torch._utils._rebuild_tensor_v2
#except AttributeError:
#    def _rebuild_tensor_v2(storage, storage_offset, size, stride, requires_grad, backward_hooks):
#        tensor = torch._utils._rebuild_tensor(storage, storage_offset, size, stride)
#        tensor.requires_grad = requires_grad
#        tensor._backward_hooks = backward_hooks
#        return tensor
#    torch._utils._rebuild_tensor_v2 = _rebuild_tensor_v2

#image_files = glob('./pic_xinwen1/*.*')

import json
import shutil
import cv2
from  datetime  import  *
import time
import traceback
from PIL import Image
sys.path.append("./pyscripts")
#import comm_log
import numpy as np
import math
#from demo import *
import jieba

def recogtext(im,savepath):#img is cv2 format
    #recog subtext
    print(savepath)
    cv2.imwrite(savepath,im)
#    tmp = Image.fromarray(cv2.cvtColor(im,cv2.COLOR_BGR2RGB))
#    tmp.save(savepath)
#    image = np.array(tmp)
#    result, image_framed, text_recs = ocr.model(image)
#    Image.fromarray(image_framed).save(savepath)
#
    segment = []
#    for key in result:
#        print(result[key][1])
#
#        #fenci
#        segs = jieba.cut(result[key][1]) 
#        for seg in segs:
#            if len(seg) > 1 and seg != '\r\n':
#                segment.append(seg)
#    print(segment)

#    return result, segment 
    return 0, segment 

def subtext_seg(shots_path, video_path):
    #print("2")
    try:
        print(video_path)

        cap = cv2.VideoCapture(video_path)

        total_frames_num = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        print("total num=%d"%total_frames_num)

        fps=int(cap.get(cv2.CAP_PROP_FPS))
        print("-fps = "+str(fps))

    #load shots info
        print(shots_path)
        shots_dict = json.load(open(shots_path,'r'))
        clip_list=[]
        videoname=None
        for key in shots_dict.keys():
            shots_dict=shots_dict[key]
            videoname=key #***.mp4
            clip_list=shots_dict["shots"]

        clip_list2=[]
        last_end = clip_list[0][1]
        for i in range(len(clip_list)):
            shot=clip_list[i]
            clip_list2.append(shot)
            if shot[0]==shot[1]:#delete same start and end shot!!!!!!!!!
               continue
            if i==0:
               continue

            if shot[0]>shot[1]:
               print(str(shots_path)+" error, start>end:  " +str(shot))
               exit()
            if shot[0]<=last_end:
               print(str(shots_path)+" error, current start<=last_end:  " +str(shot))
               exit()
            last_end=shot[1]

        clip_np = np.concatenate(clip_list2).tolist()
        print("shots:")
        print(type(clip_np))
    # end loading shots info 
        #print("2_1")

        num=-1
        sucess=True
        shot_num = 0
        frames=[]
        label=0
        before_segments = []
        samestory_pos=[] # subtext same or not in shot boundary, recording postion in video
        flag=True
        while sucess:
            num+=1
            sucess,im0 = cap.read() # get next frame
	    #crop 
            im=im0#[330:420,120:620]
            frames.append(im)
            #print("3")

            # find in shots boundary 
            if num in clip_np:
                shot_num+=1
                if num<3:
                    continue
                if  shot_num%2==0:
                    # save shots imgs before and after shots interval 
                    print("-----------")
                    savepath=frames_folder+"/"+str(num)+"_0_shot"+str(shot_num/2)+".jpg"
                    res, segments = recogtext(frames[-1], savepath)
                    savepath=frames_folder+"/"+str(num-1)+"_0_shot"+str(shot_num/2)+".jpg"
                    res, segments = recogtext(frames[-2], savepath)
                    savepath=frames_folder+"/"+str(num-2)+"_0_shot"+str(shot_num/2)+".jpg"
                    res, segments = recogtext(frames[-3], savepath)
                    label=0
                    flag=True

                else:
                    #if label<4:
                    savepath=frames_folder+"/"+str(num)+"_1_shot"+str(shot_num/2)+".jpg"
                    label +=1 
                    res, after_segments = recogtext(im,savepath)
                    flag=False
                continue


            # after shots boundary, ocr: find sub_text content
            if label<3 and flag==False:
                savepath=frames_folder+"/"+str(num)+"_1_shot"+str((shot_num/2))+".jpg"
                label +=1 
                res, after_segments = recogtext(im,savepath)


        cap.release()
        print("-youxiao frames = "+str(num))
        print("samestory stop:")

    except Exception as e:
        print(traceback.format_exc())
        print(e)

    return 0

def main():
    #print("1")
    video_path=sys.argv[1]#xinwen2/xinwen1 #os.path.join('/data2/phoebezhu/code/ClipShots_basline/20190215184605',line.split('/')[-1].strip('\n\r')+'.json')
    shots_path = sys.argv[2]

    vid = video_path.split("/")[-1]

    #data_storys
    global frames_folder
    frames_folder = "./data_storys/shots_"+vid
    if os.path.exists(frames_folder)==False:
        os.makedirs(frames_folder)
    else:
        shutil.rmtree(frames_folder)
        os.makedirs(frames_folder)

    if os.path.exists(video_path):
        subtext_seg(shots_path, video_path)
        print ('{} is done! {}')


if __name__ == '__main__':
    #comm_log.init("subtext_seg")
    main()
