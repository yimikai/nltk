# -*- coding: utf-8 -*-
import sys
#import importlib
#importlib.reload(sys)
#PYTHONIOENCODING="UTF-8"
#sys.setdefaultencoding('utf8')
import os
# os.environ['CUDA_VISIBLE_DEVICES']='0'
import time
import shutil
import numpy as np
from PIL import Image
from glob import glob
import cv2
import os

import json
import shutil
import cv2
from  datetime  import  *
import time
import traceback
from PIL import Image
sys.path.append("./pyscripts")
#import comm_log
import numpy as np
import math


def getimg_1s(video_path):
    try:
        print(video_path)

        cap = cv2.VideoCapture(video_path)

        total_frames_num = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        print("total num=%d"%total_frames_num)

        fps=int(cap.get(cv2.CAP_PROP_FPS))
        print("-fps = "+str(fps))
#########################

        num=-1
        sucess=True

        while sucess:
            num+=1
            sucess,im0 = cap.read() # get next frame
            path = frames_folder+"/"+str(num)+".jpg"
            cv2.imwrite(path,im0)
                
        cap.release()
        print("-youxiao frames = "+str(num))

    except Exception as e:
        print(traceback.format_exc())
        print(e)

    return 0

def main():
    video_path=sys.argv[1]#xinwen2/xinwen1 #os.path.join('/data2/phoebezhu/code/ClipShots_basline/20190215184605',line.split('/')[-1].strip('\n\r')+'.json')
    vid = video_path.split("/")[-1]
    global frames_folder
    frames_folder = "./testdata/imgs_"+vid
    if os.path.exists(frames_folder)==False:
        os.makedirs(frames_folder)
    else:
        shutil.rmtree(frames_folder)
        os.makedirs(frames_folder)
    if os.path.exists(video_path):
        getimg_1s(video_path)
        print ('{} is done! {}')

if __name__ == '__main__':
    #comm_log.init("getimg_1s")
    main()
